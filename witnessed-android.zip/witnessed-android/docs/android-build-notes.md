# Witnessed — Android Build Notes & Coding Tips

> Hand this to the engineer/agent (Claude Code / Codex) building the real APK.
> The HTML prototype in `witnessed/Witnessed.html` is the spec for **look, copy, flow, and mode behaviour**. This doc is the spec for **how to build it on Android without stepping on the landmines**.

Brand: **Witnessed** · parent venture studio: **Trillix** · package id suggestion: `com.trillix.witnessed`.
Keep this product's repo, database, env vars, logs and domain **separate** from any other Trillix product.

---

## 0. The one rule that drives every technical decision

**Never depend on a single sensitive permission.** Detection is tiered and degrades gracefully. The promise → receipt → mirror loop must work with **zero** permissions granted. Everything else is an upgrade the user opts into. Build the wedge (manual logging) first; it is the thing that can never be rejected from Play, never break on an OEM, and never feel creepy.

```
Tier 3  ManualProvider          no permission        <- build first, ship first
Tier 1  UsageStatsProvider      PACKAGE_USAGE_STATS  <- objective minutes, on-return mirror
Tier 2  AccessibilityProvider   AccessibilityService <- real-time wall, behind a feature flag
```

Model this as a `DetectionProvider` interface so the UI never knows which tier is live:

```kotlin
interface DetectionProvider {
    val tier: DetectionTier
    val isAvailable: Boolean          // permission granted + service running
    fun start(scope: CoroutineScope)
    fun stop()
    // emits when a watched package comes to the foreground (Tier 1/2 only)
    val attempts: SharedFlow<WatchedAppOpened>
}
```

---

## 1. Stack (MVP)

| Concern | Choice | Notes |
|---|---|---|
| Language | Kotlin | — |
| UI | Jetpack Compose + Material 3 | dark theme is the default and only theme for MVP |
| Local DB | Room | the receipt ledger; single source of truth |
| Settings | DataStore (Preferences) | promise, mode, tone, detection tier, toggles |
| Background | WorkManager | daily/weekly summary notifications |
| Detection | AccessibilityService / UsageStatsManager | tiered, see §4 |
| Intervention UI | full-screen Activity (+ optional overlay) | see §5 |
| Networking | **none** | MVP is 100% local. No backend, accounts, sync, AI, payments. |

MinSdkVersion 26+ is sane (notification channels, foreground service types). Target the latest stable SDK so Play accepts uploads.

---

## 2. Architecture shape

```
:app
  data/
    db/ (Room: WatchedAppDao, AttemptReceiptDao, AppDatabase)
    prefs/ (UserSettingsStore over DataStore)
    detection/ (DetectionProvider, Manual/UsageStats/Accessibility impls)
  domain/
    model/ (WatchedApp, AttemptReceipt, Mode, Tone, DetectionTier)
    Insights.kt (pure functions: weekly summary, danger window, reason breakdown)
  ui/
    onboarding/  intervention/  mirror/  receipts/  settings/
    theme/ (Color.kt, Type.kt, Shapes.kt)
  service/
    WitnessAccessibilityService.kt
    SummaryWorker.kt
```

Keep **Insights** as pure Kotlin functions over `List<AttemptReceipt>` — exactly like `computeStats()` in the prototype's `store.jsx`. Unit-test them; they are the product's spine. Compose just renders the result.

---

## 3. Data model (Room)

Mirror the prototype's model. Use enums, not strings, for outcome/mode/tone.

```kotlin
@Entity
data class WatchedApp(
    @PrimaryKey val id: Long = 0,        // MVP: single watched app, id = 1
    val packageName: String?,            // null for non-app behaviours ("Shopping")
    val appName: String,
    val enabled: Boolean = true,
    val createdAt: Long,
    val mode: Mode,                      // LIGHT, SERIOUS, NO_BULLSHIT
    val promiseText: String,
    val desiredOutcome: String,          // "Time", "Sleep", ...
    val tone: Tone                       // GENTLE, DIRECT, BRUTAL, COACH
)

@Entity
data class AttemptReceipt(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val watchedAppId: Long,
    val timestamp: Long,
    val hour: Int,                       // denormalised for fast histogram queries
    val outcome: Outcome,                // BACKED_OUT, CONTINUED, DISMISSED
    val reasonCategory: String?,
    val reasonText: String?,
    val interventionDurationMs: Long,    // how long the wall was on screen
    val modeAtTime: Mode
)
```

`UserSettings` lives in DataStore (not Room): `dailySummaryEnabled`, `weeklySummaryEnabled`, `privacyLockEnabled`, `detectionTier`, `onboardingCompleted`, `permissionsCompleted`.

**Store `hour` on write.** Computing danger windows over thousands of rows is trivial if the hour is already a column.

---

## 4. Detection — the careful part

### Tier 3 · Manual (build this first)
No service. A "I'm being pulled — log it" button (and a quick-settings tile / notification action) opens the intervention Activity directly. This is the prototype's primary path and the honest test of the hypothesis.

### Tier 1 · UsageStats
- Permission: `PACKAGE_USAGE_STATS` is a **special access** — you cannot `requestPermissions()` it. Send the user to `Settings.ACTION_USAGE_ACCESS_SETTINGS` and detect grant with `AppOpsManager.checkOpNoThrow(OPSTR_GET_USAGE_STATS, ...)`.
- It is **polling / after-the-fact**, not instant. Use `UsageStatsManager.queryEvents()` for `MOVE_TO_FOREGROUND` to find when the watched package was opened, and for an "on-return" mirror ("you just spent 42 min in TikTok"). Do **not** pretend this is the real-time wall.

### Tier 2 · Accessibility + Overlay (feature-flagged)
This is the only way to show the wall *before* the user scrolls.

```kotlin
class WitnessAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg !in watchedPackages) return
        if (onCooldown(pkg)) return            // see below — critical
        launchIntervention(pkg)
    }
}
```

Service config (`res/xml/accessibility_service_config.xml`): set `android:accessibilityEventTypes="typeWindowStateChanged"`, `android:canRetrieveWindowContent="false"` (you do NOT need content — only the package name), and a truthful `android:description` that Play reviewers will read.

**Gotchas that will bite you:**
- You **cannot** enable Accessibility programmatically. Deep-link to `Settings.ACTION_ACCESSIBILITY_SETTINGS` and walk the user through it with the exact copy from the prototype's permission screen. Expect drop-off; that's why it's optional.
- **The intervention loop.** When you finish the wall and the user taps "Continue", the watched app returns to foreground → fires `TYPE_WINDOW_STATE_CHANGED` again → re-triggers the wall → infinite loop. **You must implement a per-package cooldown** (e.g. ignore the same package for 60–90s after a resolved intervention, or until a different package has been foreground). The prototype models this conceptually; on-device it's mandatory.
- Some OEMs kill background services aggressively (MIUI, EMUI, etc.). If reliability matters, pair with a foreground service + a persistent low-priority notification, and surface a "fix background restrictions" helper.
- Overlay (`SYSTEM_ALERT_WINDOW` / `Settings.ACTION_MANAGE_OVERLAY_PERMISSION`) is only needed if you draw *over* the app instead of launching your own full-screen Activity. A full-screen Activity launched on the event is simpler and avoids overlay-permission policy risk — prefer it unless you specifically need to float on top.

### Play policy (read before you ship)
Accessibility and UsageStats are sensitive. Google requires they be (a) necessary for core user-facing functionality, (b) clearly disclosed in-app *before* the prompt, and (c) limited to that disclosed purpose. You will likely need a **Permissions Declaration Form** and possibly a demo video. Because Witnessed never reads window *content*, lean on that in the declaration: keep `canRetrieveWindowContent="false"`.

---

## 5. The intervention Activity

- Single-top, `excludeFromRecents`, `screenOrientation=portrait`, theme with no action bar, drawn edge-to-edge over the status bar (the wall should feel total — unlike the prototype which is clipped to the device frame).
- Hardware **back** = "Back out" (the affirming choice). Never let back silently dismiss without logging a `DISMISSED` receipt.
- Record `interventionDurationMs` from `onResume` to the resolving tap — it's a quality signal for the beta ("did the pause actually make them sit with it").
- Mode behaviour (identical to the prototype — see `intervention.jsx`):
  - **Light:** promise + Back out / Continue. Continue logs `CONTINUED` immediately, no reason.
  - **Serious:** Continue → required reason chips → Save.
  - **No Bullshit:** a real `CountDownTimer` (5s) gates the Continue button; then a **typed** reason (min length) **and** an explicit "I understand I'm choosing this" confirmation before Continue is enabled.
- Copy is fixed; only **tone** swaps the subline (`INTERVENTION_SUB` map in the prototype).

---

## 6. Notifications (WorkManager)

- One channel per cadence; respect the DataStore toggles.
- Notifications are **insight-led, never generic** — generate the line from `Insights` + tone, mirroring the prototype's preview logic:
  - Light: "You had 6 temptation moments today. Want to see the pattern?"
  - Serious: "You continued 4 times today. Want the receipts?"
  - No Bullshit: "{App} ran your evening again. Look at the pattern."
- Schedule the daily summary in the evening; schedule a "danger window is starting" nudge from the computed worst 3-hour window.

---

## 7. Privacy & red lines (encode these as tests/guards, not just docs)

Collect only: chosen package name, attempt timestamp, outcome, reason, promise, settings, optional journal note.
Never collect: message/screen content, keystrokes, other apps, watched-app *internals*, contacts, location, ad IDs.

- No analytics SDK that phones home in MVP. If you add crash reporting later, no PII, opt-in.
- `canRetrieveWindowContent="false"` — and never call `rootInActiveWindow` for content. You only need `event.packageName`.
- Ship **export** (JSON/CSV of receipts) and **delete-all** as first-class one-tap actions (the prototype's Settings → Data section). Deletion must actually wipe Room + DataStore.
- Tone guard: confronting, never humiliating. Keep the "bad copy" list from the brief as a literal lint/PR checklist.

---

## 8. Build order (match the prototype, ship the wedge)

1. Onboarding + DataStore (promise, outcome, mode, tone).
2. Room + manual logging + the intervention Activity (Tier 3 path).
3. Danger-window WorkManager notifications.
4. Receipts ledger screen.
5. Mirror dashboard (Insights functions + Compose, depth gated by mode).
6. Tier 1 UsageStats (objective minutes, on-return mirror).
7. Tier 2 Accessibility wall behind a feature flag — last, with the cooldown solved.

The MVP succeeds if a user can start in <2 min, create one promise, log moments, get danger-window nudges, see receipts, understand their pattern, and trust what is/ isn't tracked. The single question the beta answers: **does seeing your own promise at the danger moment change what you do next?**

---

## 9. Theme tokens (port from the prototype's `styles.css`)

```kotlin
// Color.kt  (warm near-black ledger)
val Bg        = Color(0xFF18170F)
val Surface   = Color(0xFF24221A)
val Surface2  = Color(0xFF2B2920)
val TextMain  = Color(0xFFECE6DA)   // warm off-white
val TextDim   = Color(0xFFA59E8E)
val Accent    = Color(0xFFD4754D)   // the ONE action accent
val Kept      = Color(0xFF8A9A7E)   // restrained positive (promise kept)
```

Type: **Newsreader** (serif) for the promise & emotional statements, **Schibsted Grotesk** for UI, **JetBrains Mono** for receipt timestamps/labels. Bundle the fonts; don't rely on Downloadable Fonts for the wall (it must render instantly, even offline).

