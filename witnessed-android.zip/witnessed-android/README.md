# Witnessed — Android (MVP, Tier-3 manual)

A private behaviour ledger. Write a promise to yourself; when you feel the pull,
log the moment and see your own words. Witnessed keeps the receipt and shows you
the pattern. **100% local — no account, no network, no sensitive permissions.**

This is the **Tier-3 (manual) MVP** from `docs/android-build-notes.md`: the wedge
that needs *zero* permissions and therefore installs and runs anywhere. Usage-access
and Accessibility detection (Tiers 1–2) are scaffolded in the UI but intentionally
not wired to system services yet — see the build notes for the staged plan.

Package: `com.trillix.witnessed` · debug builds install as `…witnessed.debug`.

---

## What works
- Onboarding: pick a behaviour → what you want back → write the promise → mode → privacy → detection level.
- The **wall** (full-screen Activity) with real per-mode behaviour:
  - **Light** — promise, Back out / Continue (Continue logs immediately).
  - **Serious** — Continue requires a reason chip.
  - **No Bullshit** — a 5-second gate, then a typed reason **and** an explicit “I understand I’m choosing this”.
- **Receipts** ledger (Room), grouped by day, filterable.
- **Mirror** dashboard whose depth scales with mode (today tiles → week summary → promise-kept meter → reason breakdown → danger window).
- **Settings**: edit promise, switch mode/tone live, detection tier, notification toggles, privacy panel, reseed / clear / reset.
- A daily **WorkManager** summary notification, insight-led and tone-aware.

The “I’m being pulled — log it” button is the manual trigger (Tier 3). It opens the wall directly.

---

## Build it — two ways

### A. Cloud build (no local setup) — recommended
1. Create a new repo on GitHub and push this folder (the folder containing `settings.gradle.kts`) to the `main` branch.
2. The included workflow `.github/workflows/android-build.yml` runs automatically.
   You can also trigger it by hand: repo → **Actions** → *Build Witnessed APK* → **Run workflow**.
3. When it finishes (green check), open the run → **Artifacts** → download **`witnessed-debug-apk`**.
4. Unzip it; inside is `app-debug.apk`. Copy it to your Android phone and open it to install
   (you’ll need to allow “install from unknown sources” for your file manager — Android prompts you).

The runner has full network access to Google’s Android SDK and Maven, so it resolves everything itself.

### B. Android Studio (local)
1. Install **Android Studio** (Koala/2024.1 or newer). It bundles a compatible JDK and Gradle.
2. **File → Open** this folder and let it sync. (If it reports a missing Gradle wrapper jar,
   accept its offer to generate the wrapper, or run `gradle wrapper --gradle-version 8.7` in the
   built-in Terminal.)
3. Plug in a phone with USB debugging on (or start an emulator) and press **Run ▶**.
   To get just the file: **Build → Build App Bundle(s) / APK(s) → Build APK(s)**; the result lands in
   `app/build/outputs/apk/debug/app-debug.apk`.

### Toolchain versions (already pinned)
- Android Gradle Plugin 8.5.2 · Kotlin 1.9.24 · Compose Compiler 1.5.14 · Compose BOM 2024.06.00
- Gradle 8.7 · JDK 17 · compileSdk/targetSdk 34 · minSdk 26
- Room 2.6.1 (kapt) · DataStore 1.1.1 · WorkManager 2.9.0

---

## Notes / next steps
- **Fonts:** the prototype calls for Newsreader / Schibsted Grotesk / JetBrains Mono. To keep the
  build self-contained this uses the system serif/sans/mono families. Drop the real `.ttf` files into
  `app/src/main/res/font/` and point `ui/theme/Type.kt` at them to match the prototype exactly.
- **Detection tiers 1–2:** wiring `UsageStatsManager` and an `AccessibilityService` (with the
  mandatory per-package cooldown) is the staged work in `docs/android-build-notes.md §4`. Keep
  `canRetrieveWindowContent="false"` and lead the Play declaration with “never reads window content”.
- **Privacy red lines** from the build notes are honoured here: the app stores only the chosen
  behaviour, timestamps, outcome, reason, promise and settings — nothing else — and has no analytics
  or network code.
