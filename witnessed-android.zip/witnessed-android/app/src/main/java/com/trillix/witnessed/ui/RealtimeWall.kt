package com.trillix.witnessed.ui

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.trillix.witnessed.data.DetectionTier
import com.trillix.witnessed.data.InstalledApp
import com.trillix.witnessed.data.loadInstalledApps
import com.trillix.witnessed.service.WitnessAccessibilityService
import com.trillix.witnessed.ui.theme.AccentText
import com.trillix.witnessed.ui.theme.Bg
import com.trillix.witnessed.ui.theme.Dim
import com.trillix.witnessed.ui.theme.Kept
import com.trillix.witnessed.ui.theme.Line
import com.trillix.witnessed.ui.theme.Mono
import com.trillix.witnessed.ui.theme.Sans
import com.trillix.witnessed.ui.theme.Surface1
import com.trillix.witnessed.ui.theme.Surface2
import com.trillix.witnessed.ui.theme.TextMain

@Composable
fun RealtimeWallSection(state: UiState, vm: AppViewModel) {
    val context = LocalContext.current
    val app = state.app ?: return
    var showPicker by remember { mutableStateOf(false) }
    // Recomputed each composition; refreshes when you return to the app.
    val serviceOn = isAccessibilityServiceEnabled(context)
    val live = serviceOn && state.settings.detection == DetectionTier.ACCESSIBILITY && !app.packageName.isNullOrBlank()

    Column(Modifier.fillMaxWidth().padding(bottom = 26.dp)) {
        Kicker("Real-time wall")
        Spacer(Modifier.height(12.dp))

        Card(strong = true) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                VIcon("shield", size = 20.dp, color = AccentText)
                Spacer(Modifier.width(10.dp))
                Text(
                    if (live) "On — the wall appears the moment you open the app."
                    else "Off — set it up below to catch yourself automatically.",
                    color = if (live) Kept else Dim, fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 14.sp,
                )
            }
            Spacer(Modifier.height(8.dp))
            Tiny("Witnessed only notices when your chosen app opens — never screen content, messages, or keystrokes.")
        }

        Spacer(Modifier.height(12.dp))

        // 1) choose the real app to watch
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(Surface1)
                .border(1.dp, Line, RoundedCornerShape(13.dp))
                .clickable { showPicker = true }.padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text("App to watch", color = TextMain, fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 15.sp)
                Tiny(if (app.packageName.isNullOrBlank()) "Not chosen yet — tap to pick" else "${app.appName} · ${app.packageName}")
            }
            VIcon("chevron", size = 18.dp, color = Dim)
        }

        Spacer(Modifier.height(9.dp))

        // 2) turn the service on (or confirm it's running)
        if (live) {
            QuietButton("Open accessibility settings") { openAccessibilitySettings(context) }
        } else {
            PrimaryButton(
                if (app.packageName.isNullOrBlank()) "Pick an app first" else "Turn on the wall",
                enabled = !app.packageName.isNullOrBlank(),
            ) {
                vm.setDetection(DetectionTier.ACCESSIBILITY)
                openAccessibilitySettings(context)
            }
        }
        Spacer(Modifier.height(10.dp))
        Tiny(
            "Android requires you to switch Witnessed on under Settings → Accessibility. " +
                "Find “Witnessed — the wall” and enable it. It is always optional and reads no content."
        )
    }

    if (showPicker) {
        AppPickerDialog(
            onPick = { picked ->
                vm.updateApp { it.copy(packageName = picked.packageName, appName = picked.label) }
                showPicker = false
            },
            onDismiss = { showPicker = false },
        )
    }
}

@Composable
private fun AppPickerDialog(onPick: (InstalledApp) -> Unit, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val apps = remember { loadInstalledApps(context) }
    Dialog(onDismissRequest = onDismiss) {
        Surface(color = Bg, shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                Text("Choose the app to watch", color = TextMain, fontFamily = Sans,
                    fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Spacer(Modifier.height(4.dp))
                Tiny("The one that costs you the most. ${apps.size} apps found.")
                Spacer(Modifier.height(12.dp))
                LazyColumn(Modifier.fillMaxWidth().heightIn(max = 420.dp)) {
                    items(apps) { a ->
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                                .clickable { onPick(a) }.padding(horizontal = 8.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Box(
                                Modifier.size(30.dp).clip(RoundedCornerShape(8.dp)).background(Surface2),
                                contentAlignment = Alignment.Center,
                            ) { Text(a.label.take(1).uppercase(), color = AccentText, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(a.label, color = TextMain, fontFamily = Sans, fontSize = 15.sp)
                                Text(a.packageName, color = Dim, fontFamily = Mono, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun openAccessibilitySettings(context: Context) {
    context.startActivity(
        Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    )
}

private fun isAccessibilityServiceEnabled(context: Context): Boolean {
    val expected = ComponentName(context, WitnessAccessibilityService::class.java).flattenToString()
    val enabled = Settings.Secure.getString(
        context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
    ) ?: return false
    return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
}
