package com.trillix.witnessed

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.trillix.witnessed.service.SummaryWorker
import java.util.concurrent.TimeUnit

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Graph.init(this)
        createChannel()
        scheduleSummaries()
    }

    private fun createChannel() {
        val mgr = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Mirror summaries",
            NotificationManager.IMPORTANCE_DEFAULT,
        ).apply { description = "Insight-led summaries of your pattern." }
        mgr.createNotificationChannel(channel)
    }

    private fun scheduleSummaries() {
        val request = PeriodicWorkRequestBuilder<SummaryWorker>(1, TimeUnit.DAYS).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "daily_summary",
            ExistingPeriodicWorkPolicy.KEEP,
            request,
        )
    }

    companion object {
        const val CHANNEL_ID = "witnessed_summary"
    }
}
