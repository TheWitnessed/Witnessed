package com.trillix.witnessed.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.trillix.witnessed.ui.theme.Accent
import com.trillix.witnessed.ui.theme.AccentLine
import com.trillix.witnessed.ui.theme.AccentSoft
import com.trillix.witnessed.ui.theme.AccentText
import com.trillix.witnessed.ui.theme.Dim
import com.trillix.witnessed.ui.theme.Faint
import com.trillix.witnessed.ui.theme.Kept
import com.trillix.witnessed.ui.theme.Line
import com.trillix.witnessed.ui.theme.LineStrong
import com.trillix.witnessed.ui.theme.Mono
import com.trillix.witnessed.ui.theme.OnAccent
import com.trillix.witnessed.ui.theme.Sans
import com.trillix.witnessed.ui.theme.Serif
import com.trillix.witnessed.ui.theme.Surface1
import com.trillix.witnessed.ui.theme.Surface2
import com.trillix.witnessed.ui.theme.Surface3
import com.trillix.witnessed.ui.theme.TextMain

// ---- Line icons (subpaths in a 24x24 box, stroked) -------------------------
private val ICONS: Map<String, List<String>> = mapOf(
    "back" to listOf("M15 5l-7 7 7 7"),
    "close" to listOf("M6 6l12 12", "M18 6L6 18"),
    "check" to listOf("M5 12.5l4.5 4.5L19 6.5"),
    "plus" to listOf("M12 5v14", "M5 12h14"),
    "chevron" to listOf("M9 5l7 7-7 7"),
    "mirror" to listOf(
        "M7 3 H17 A3 3 0 0 1 20 6 V18 A3 3 0 0 1 17 21 H7 A3 3 0 0 1 4 18 V6 A3 3 0 0 1 7 3 Z",
        "M8 8h8", "M8 12h8", "M8 16h5"
    ),
    "receipt" to listOf("M6 3h12v18l-3-2-3 2-3-2-3 2V3z", "M9 8h6", "M9 12h6"),
    "gear" to listOf(
        "M12 8.8 A3.2 3.2 0 1 1 11.99 8.8 Z",
        "M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"
    ),
    "door" to listOf("M6 21V5a2 2 0 012-2h8a2 2 0 012 2v16", "M4 21h16", "M14 12h.5"),
    "clock" to listOf("M12 3 A9 9 0 1 1 11.99 3 Z", "M12 7v5l3 2"),
    "shield" to listOf("M12 3l7 3v6c0 4-3 7-7 9-4-2-7-5-7-9V6l7-3z", "M9 12l2 2 4-4"),
    "bell" to listOf("M6 9a6 6 0 0112 0c0 5 2 6 2 6H4s2-1 2-6z", "M10 19a2 2 0 004 0"),
    "trash" to listOf("M4 7h16M9 7V5a1 1 0 011-1h4a1 1 0 011 1v2M6 7l1 13h10l1-13"),
    "hand" to listOf(
        "M8 13V6a1.5 1.5 0 013 0v5m0-1V4.5a1.5 1.5 0 013 0V11m0-1V6.5a1.5 1.5 0 013 0V14" +
            "c0 4-2.5 7-6 7s-6-2-6-5l-1.5-3a1.5 1.5 0 012.6-1.5L11 13"
    ),
)

@Composable
fun VIcon(name: String, size: Dp = 22.dp, color: Color = TextMain, sw: Float = 1.7f) {
    val subpaths = ICONS[name] ?: ICONS["check"]!!
    Canvas(modifier = Modifier.size(size)) {
        val scale = this.size.minDimension / 24f
        scale(scale, scale, pivot = Offset.Zero) {
            subpaths.forEach { d ->
                val path = PathParser().parsePathString(d).toPath()
                drawPath(
                    path = path,
                    color = color,
                    style = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
                )
            }
        }
    }
}

@Composable
fun Seal(size: Dp = 40.dp, ink: Color = Accent, stroke: Color = TextMain) {
    Canvas(modifier = Modifier.size(size)) {
        val scale = this.size.minDimension / 64f
        scale(scale, scale, pivot = Offset.Zero) {
            drawRoundRect(
                color = stroke.copy(alpha = 0.9f),
                topLeft = Offset(4.5f, 4.5f),
                size = Size(55f, 55f),
                cornerRadius = CornerRadius(15f, 15f),
                style = Stroke(width = 2.4f)
            )
            drawRoundRect(
                color = stroke.copy(alpha = 0.45f),
                topLeft = Offset(10f, 10f),
                size = Size(44f, 44f),
                cornerRadius = CornerRadius(11f, 11f),
                style = Stroke(width = 1.1f)
            )
            drawPath(
                path = PathParser().parsePathString("M18 23 L25 43 L32 28 L39 43 L46 23").toPath(),
                color = ink,
                style = Stroke(width = 3f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
            drawPath(
                path = PathParser().parsePathString("M22 49 H42").toPath(),
                color = stroke.copy(alpha = 0.55f),
                style = Stroke(width = 2f, cap = StrokeCap.Round)
            )
        }
    }
}

// ---- Text helpers ----------------------------------------------------------
@Composable
fun Kicker(text: String, modifier: Modifier = Modifier) {
    Text(
        text = text.uppercase(),
        modifier = modifier,
        color = Faint,
        fontFamily = Mono,
        fontSize = 11.sp,
        letterSpacing = 2.2.sp,
    )
}

@Composable
fun H1(text: String, modifier: Modifier = Modifier, size: Int = 30) {
    Text(text, modifier = modifier, color = TextMain, fontFamily = Serif,
        fontWeight = FontWeight.Medium, fontSize = size.sp, lineHeight = (size * 1.12f).sp)
}

@Composable
fun Lead(text: String, modifier: Modifier = Modifier) {
    Text(text, modifier = modifier, color = Dim, fontSize = 15.sp, lineHeight = 22.sp)
}

@Composable
fun Tiny(text: String, modifier: Modifier = Modifier, align: TextAlign? = null) {
    Text(text, modifier = modifier, color = Faint, fontSize = 12.5.sp, lineHeight = 18.sp, textAlign = align)
}

// ---- Buttons ---------------------------------------------------------------
@Composable
fun PrimaryButton(
    text: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    icon: String? = null,
    onClick: () -> Unit,
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(13.dp))
            .background(if (enabled) Accent else Accent.copy(alpha = 0.4f))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(vertical = 16.dp, horizontal = 20.dp),
        contentAlignment = Alignment.Center,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            if (icon != null) {
                VIcon(icon, size = 18.dp, color = OnAccent, sw = 2f)
                Spacer(Modifier.width(9.dp))
            }
            Text(text, color = OnAccent, fontFamily = Sans, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
        }
    }
}

@Composable
fun GhostButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(13.dp))
            .border(1.dp, LineStrong, RoundedCornerShape(13.dp))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(vertical = 16.dp, horizontal = 20.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = if (enabled) TextMain else Dim, fontFamily = Sans,
            fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
    }
}

@Composable
fun QuietButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(13.dp))
            .background(Surface2)
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp, horizontal = 18.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = TextMain, fontFamily = Sans, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
    }
}

// ---- Surfaces --------------------------------------------------------------
@Composable
fun Card(
    modifier: Modifier = Modifier,
    accent: Boolean = false,
    strong: Boolean = false,
    content: @Composable () -> Unit,
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(if (accent) AccentSoft else Surface1)
            .border(1.dp, if (accent) AccentLine else if (strong) LineStrong else Line, RoundedCornerShape(18.dp))
            .padding(18.dp),
    ) { Column { content() } }
}

@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(11.dp))
            .background(if (selected) AccentSoft else Surface1)
            .border(1.dp, if (selected) AccentLine else Line, RoundedCornerShape(11.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 15.dp, vertical = 11.dp),
    ) {
        Text(text, color = if (selected) AccentText else TextMain, fontFamily = Sans,
            fontWeight = FontWeight.Medium, fontSize = 14.5.sp)
    }
}

@Composable
fun StatTile(n: String, label: String, accent: Boolean = false, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Surface1)
            .border(1.dp, Line, RoundedCornerShape(14.dp))
            .padding(15.dp),
    ) {
        Column {
            Text(n, color = if (accent) AccentText else TextMain, fontFamily = Serif,
                fontWeight = FontWeight.Medium, fontSize = 30.sp, lineHeight = 30.sp)
            Spacer(Modifier.size(7.dp))
            Text(label.uppercase(), color = Faint, fontFamily = Mono, fontSize = 10.5.sp, letterSpacing = 1.sp)
        }
    }
}

@Composable
fun Meter(pct: Int, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(7.dp)
            .clip(RoundedCornerShape(99.dp))
            .background(Surface3),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(fraction = (pct.coerceIn(0, 100)) / 100f)
                .height(7.dp)
                .clip(RoundedCornerShape(99.dp))
                .background(Kept),
        )
    }
}

@Composable
fun PromiseQuote(text: String, modifier: Modifier = Modifier, size: Int = 18) {
    Text(
        "“$text”",
        modifier = modifier,
        color = TextMain,
        fontFamily = Serif,
        fontStyle = FontStyle.Italic,
        fontSize = size.sp,
        lineHeight = (size * 1.33f).sp,
    )
}
