package com.trillix.witnessed

import android.content.Context
import androidx.room.Room
import com.trillix.witnessed.data.AppDatabase
import com.trillix.witnessed.data.Repository
import com.trillix.witnessed.data.SettingsStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** Tiny manual DI container — one database + repository for the whole process. */
object Graph {
    lateinit var repository: Repository
        private set

    /** Outlives any single Activity — use for fire-and-forget DB writes. */
    val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun init(context: Context) {
        if (::repository.isInitialized) return
        val db = Room.databaseBuilder(
            context.applicationContext,
            AppDatabase::class.java,
            "witnessed.db"
        ).fallbackToDestructiveMigration().build()
        repository = Repository(
            db.watchedAppDao(),
            db.receiptDao(),
            SettingsStore(context.applicationContext)
        )
    }
}
