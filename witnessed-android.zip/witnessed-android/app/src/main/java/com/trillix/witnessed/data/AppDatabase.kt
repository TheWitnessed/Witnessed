package com.trillix.witnessed.data

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

@Database(
    entities = [WatchedApp::class, AttemptReceipt::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun watchedAppDao(): WatchedAppDao
    abstract fun receiptDao(): ReceiptDao
}
