package com.trillix.witnessed.data

/** Static option catalogs + copy, ported from the prototype's store.jsx. */

data class Option(val id: String, val name: String, val color: Long = 0xFF343126, val glyph: String = "")

val CONTROL_OPTS = listOf(
    Option("tiktok", "TikTok", 0xFF2C2C2E, "T"),
    Option("instagram", "Instagram", 0xFF9B4A78, "Ig"),
    Option("youtube", "YouTube", 0xFF8C3B34, "▶"),
    Option("x", "X / Twitter", 0xFF33312B, "X"),
    Option("shopping", "Shopping", 0xFF6A5A3A, "⌂"),
    Option("food", "Food delivery", 0xFF7A5230, "◷"),
    Option("gambling", "Gambling", 0xFF3C5A46, "◆"),
    Option("porn", "Porn", 0xFF4A3550, "●"),
    Option("messaging", "Messaging someone", 0xFF3A4A5A, "✉"),
    Option("other", "Something else", 0xFF444038, "?"),
)

val OUTCOME_OPTS = listOf(
    Option("time", "Time"),
    Option("focus", "Focus"),
    Option("sleep", "Sleep"),
    Option("money", "Money"),
    Option("peace", "Peace"),
    Option("respect", "Self-respect"),
    Option("rel", "My relationship"),
    Option("life", "My life"),
)

val PROMISE_EXAMPLES = listOf(
    "I said I wanted my evenings back.",
    "I open this when I’m avoiding work.",
    "If I open this now, I know I’ll lose the next hour.",
    "I promised myself I’d sleep before midnight.",
    "I want to be present tonight.",
)

val REASONS = listOf(
    Option("bored", "Bored"),
    Option("stressed", "Stressed"),
    Option("avoiding", "Avoiding something"),
    Option("lonely", "Lonely"),
    Option("habit", "Habit"),
    Option("nocare", "I don’t care right now"),
    Option("other", "Other"),
)

fun reasonName(id: String?): String? =
    id?.let { rid -> REASONS.firstOrNull { it.id == rid }?.name ?: rid }

data class ModeInfo(val mode: Mode, val name: String, val line: String, val desc: String, val glyph: String)

val MODE_INFO = mapOf(
    Mode.LIGHT to ModeInfo(
        Mode.LIGHT, "Light", "Show me the mirror.",
        "Soft reminders. Easy continue. Reason optional. Simple receipts.", "◔"
    ),
    Mode.SERIOUS to ModeInfo(
        Mode.SERIOUS, "Serious", "Make me explain myself.",
        "You can back out or continue — but continuing means choosing a reason. Stronger daily receipts.", "◑"
    ),
    Mode.NOBULL to ModeInfo(
        Mode.NOBULL, "No Bullshit", "Don’t let me lie to myself.",
        "A pause before you can continue. Type why. Confirm the choice out loud. The full pattern, unflinching.", "●"
    ),
)

val TONE_NAME = mapOf(
    Tone.GENTLE to "Gentle",
    Tone.DIRECT to "Direct",
    Tone.BRUTAL to "Brutal",
    Tone.COACH to "Coach",
)

val INTERVENTION_SUB = mapOf(
    Tone.GENTLE to "This moment is now on the record. No shame — just a receipt.",
    Tone.DIRECT to "This moment is now on the record.",
    Tone.BRUTAL to "You already know how this ends. It’s on the record either way.",
    Tone.COACH to "You’ve paused before and won. You can do it again. On the record.",
)
