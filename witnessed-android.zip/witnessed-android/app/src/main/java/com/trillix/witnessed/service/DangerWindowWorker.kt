package com.trillix.witnessed.service

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.trillix.witnessed.App
import com.trillix.witnessed.Graph
import com.trillix.witnessed.MainActivity
import com.trillix.witnessed.R
import com.trillix.witnessed.data.Mode
import com.trillix.witnessed.data.WatchedApp
import com.trillix.witnessed.domain.Insights
import com.trillix.witnessed.domain.Stats
import java.util.Calendar
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.flow.first

/**
 * Fires a tone-aware "your danger window is starting" nudge at the computed
 * worst 3-hour window, then reschedules itself for the next day.
 */
class DangerWindowWorker(
    context: Context,
    params: WorkerParameters,
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val repo = Graph.repository
        val app = repo.currentApp() ?: return Result.success()
        val settings = repo.userSettings.first()
        val stats = Insights.compute(repo.snapshotReceipts())

        val fire = inputData.getBoolean(KEY_FIRE, false)
        if (fire && settings.dailySummary && stats.week.total > 0) {
            postNudge(app, stats)
        }
        schedule(applicationContext, stats.week.worstStart, ExistingWorkPolicy.REPLACE)
        return Result.success()
    }

    private fun postNudge(app: WatchedApp, stats: Stats) {
        val window = stats.week.dangerWindow
        val text = when (app.mode) {
            Mode.LIGHT -> "Your heavy hours are starting ($window). A good moment to stay ahead of it."
            Mode.SERIOUS -> "${app.appName} usually pulls you in around now ($window). Heads up."
            Mode.NOBULL -> "This is when ${app.appName} runs your evening ($window). You know the pattern."
        }
        val ctx = applicationContext
        val pending = PendingIntent.getActivity(
            ctx, 1,
            Intent(ctx, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val n = NotificationCompat.Builder(ctx, App.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Witnessed")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(pending)
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(ctx).notify(2, n)
        } catch (_: SecurityException) {
        }
    }

    companion object {
        const val KEY_FIRE = "fire"
        const val UNIQUE = "danger_window"

        /** Schedule the next timed run at the next occurrence of [hour]:00. */
        fun schedule(context: Context, hour: Int, policy: ExistingWorkPolicy) {
            val now = Calendar.getInstance()
            val target = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour.coerceIn(0, 23))
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            if (target.timeInMillis <= now.timeInMillis) target.add(Calendar.DAY_OF_YEAR, 1)
            val delay = target.timeInMillis - now.timeInMillis
            val req = OneTimeWorkRequestBuilder<DangerWindowWorker>()
                .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                .setInputData(workDataOf(KEY_FIRE to true))
                .build()
            WorkManager.getInstance(context).enqueueUniqueWork(UNIQUE, policy, req)
        }

        /** Bootstrap from App.onCreate: compute the window and arm the timer. */
        fun seed(context: Context) {
            val req = OneTimeWorkRequestBuilder<DangerWindowWorker>()
                .setInputData(workDataOf(KEY_FIRE to false))
                .build()
            WorkManager.getInstance(context).enqueueUniqueWork(UNIQUE, ExistingWorkPolicy.KEEP, req)
        }
    }
}
