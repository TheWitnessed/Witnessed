package com.trillix.witnessed

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts.RequestPermission
import androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.trillix.witnessed.data.Outcome
import com.trillix.witnessed.ui.AppViewModel
import com.trillix.witnessed.ui.HomeScreen
import com.trillix.witnessed.ui.Onboarding
import com.trillix.witnessed.ui.theme.Bg
import com.trillix.witnessed.ui.theme.WitnessedTheme

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    private val interventionLauncher =
        registerForActivityResult(StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                when (result.data?.getStringExtra(InterventionActivity.EXTRA_OUTCOME)) {
                    Outcome.BACKED_OUT.name ->
                        Toast.makeText(this, "You kept your promise. That counts.", Toast.LENGTH_SHORT).show()
                    Outcome.CONTINUED.name ->
                        Toast.makeText(this, "Receipt saved. It’s on the record.", Toast.LENGTH_SHORT).show()
                }
            }
        }

    private val notifPermissionLauncher =
        registerForActivityResult(RequestPermission()) { /* result ignored; app works either way */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        requestNotificationPermission()

        setContent {
            WitnessedTheme {
                val state by vm.state.collectAsState()
                androidx.compose.foundation.layout.Box(Modifier.fillMaxSize().background(Bg)) {
                    if (state.loading) {
                        // brief empty frame while the first DB read resolves
                    } else if (!state.onboardingComplete) {
                        Onboarding { app, detection -> vm.completeOnboarding(app, detection) }
                    } else {
                        HomeScreen(state, vm) {
                            interventionLauncher.launch(Intent(this@MainActivity, InterventionActivity::class.java))
                        }
                    }
                }
            }
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
            if (!granted) notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}
