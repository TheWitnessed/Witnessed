package com.trillix.witnessed.ui.theme

import androidx.compose.ui.text.font.FontFamily

// System families stand in for Newsreader / Schibsted Grotesk / JetBrains Mono.
// Drop real fonts into res/font and swap these to FontFamily(Font(...)) later.
val Serif = FontFamily.Serif
val Sans = FontFamily.SansSerif
val Mono = FontFamily.Monospace
