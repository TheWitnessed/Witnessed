package com.trillix.witnessed.service

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.trillix.witnessed.App
import com.trillix.witnessed.Graph
import com.trillix.witnessed.MainActivity
import com.trillix.witnessed.R
import com.trillix.witnessed.data.Mode
import com.trillix.witnessed.domain.Insights
import kotlinx.coroutines.flow.first

class SummaryWorker(
    context: Context,
    params: WorkerParameters,
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val repo = Graph.repository
        val settings = repo.userSettings.first()
        if (!settings.dailySummary) return Result.success()
        val app = repo.currentApp() ?: return Result.success()
        val stats = Insights.compute(repo.snapshotReceipts())

        val line = when (app.mode) {
            Mode.LIGHT -> "You had ${stats.today.total} temptation moments today. Want to see the pattern?"
            Mode.SERIOUS -> "You continued ${stats.today.cont} times today. Want the receipts?"
            Mode.NOBULL -> "${app.appName} ran your evening again. Look at the pattern."
        }
        postNotification(line)
        return Result.success()
    }

    private fun postNotification(text: String) {
        val ctx = applicationContext
        val intent = Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        val pending = PendingIntent.getActivity(
            ctx, 0, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val notification = NotificationCompat.Builder(ctx, App.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Witnessed")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(pending)
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(ctx).notify(1, notification)
        } catch (_: SecurityException) {
            // POST_NOTIFICATIONS not granted (Android 13+); nothing to do.
        }
    }
}
