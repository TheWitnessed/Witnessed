package com.trillix.witnessed.ui.theme

import androidx.compose.ui.graphics.Color

// Warm near-black ledger palette (ported from styles.css tokens).
val Bg = Color(0xFF18170F)
val Bg2 = Color(0xFF1E1C14)
val Surface1 = Color(0xFF24221A)
val Surface2 = Color(0xFF2B2920)
val Surface3 = Color(0xFF343126)

val Line = Color(0x17ECE6DA)        // ~0.09
val LineStrong = Color(0x29ECE6DA)  // ~0.16
val LineDash = Color(0x38ECE6DA)    // ~0.22

val TextMain = Color(0xFFECE6DA)
val Dim = Color(0xFFA59E8E)
val Faint = Color(0xFF756F61)

val Accent = Color(0xFFD4754D)
val AccentText = Color(0xFFE79A72)
val AccentSoft = Color(0x21D4754D)  // ~0.13
val AccentLine = Color(0x57D4754D)  // ~0.34
val OnAccent = Color(0xFF1A130D)

val Kept = Color(0xFF8A9A7E)
val KeptSoft = Color(0x218A9A7E)
