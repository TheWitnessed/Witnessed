package com.trillix.witnessed.data

import java.util.Calendar
import kotlinx.coroutines.flow.Flow

class Repository(
    private val appDao: WatchedAppDao,
    private val receiptDao: ReceiptDao,
    val settings: SettingsStore,
) {
    val watchedApp: Flow<WatchedApp?> = appDao.observe()
    val receipts: Flow<List<AttemptReceipt>> = receiptDao.observeAll()
    val userSettings: Flow<UserSettings> = settings.flow

    suspend fun completeOnboarding(app: WatchedApp, detection: DetectionTier) {
        appDao.upsert(app)
        receiptDao.clear()
        settings.setDetection(detection)
        settings.setOnboardingComplete(true)
    }

    suspend fun updateApp(transform: (WatchedApp) -> WatchedApp) {
        val cur = appDao.get() ?: return
        appDao.upsert(transform(cur))
    }

    suspend fun logReceipt(
        outcome: Outcome,
        reasonCategory: String? = null,
        reasonText: String? = null,
        durationMs: Long = 0,
    ) {
        val app = appDao.get() ?: return
        val cal = Calendar.getInstance()
        receiptDao.insert(
            AttemptReceipt(
                timestamp = cal.timeInMillis,
                hour = cal.get(Calendar.HOUR_OF_DAY),
                outcome = outcome,
                reasonCategory = reasonCategory,
                reasonText = reasonText,
                interventionDurationMs = durationMs,
                modeAtTime = app.mode,
                promiseAtTime = app.promiseText,
                seeded = false,
            )
        )
    }

    suspend fun clearReceipts() = receiptDao.clear()

    suspend fun resetAll() {
        receiptDao.clear()
        appDao.clear()
        settings.clear()
    }

    suspend fun currentApp(): WatchedApp? = appDao.get()
    suspend fun snapshotReceipts(): List<AttemptReceipt> = receiptDao.getAll()
}
