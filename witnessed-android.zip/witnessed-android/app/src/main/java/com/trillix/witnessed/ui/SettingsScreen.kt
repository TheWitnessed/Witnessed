package com.trillix.witnessed.ui

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.trillix.witnessed.data.DetectionTier
import com.trillix.witnessed.data.MODE_INFO
import com.trillix.witnessed.data.Mode
import com.trillix.witnessed.data.OUTCOME_OPTS
import com.trillix.witnessed.data.TONE_NAME
import com.trillix.witnessed.data.Tone
import com.trillix.witnessed.ui.theme.Accent
import com.trillix.witnessed.ui.theme.AccentLine
import com.trillix.witnessed.ui.theme.AccentSoft
import com.trillix.witnessed.ui.theme.AccentText
import com.trillix.witnessed.ui.theme.Bg2
import com.trillix.witnessed.ui.theme.Dim
import com.trillix.witnessed.ui.theme.Faint
import com.trillix.witnessed.ui.theme.Kept
import com.trillix.witnessed.ui.theme.Line
import com.trillix.witnessed.ui.theme.LineStrong
import com.trillix.witnessed.ui.theme.Mono
import com.trillix.witnessed.ui.theme.OnAccent
import com.trillix.witnessed.ui.theme.Sans
import com.trillix.witnessed.ui.theme.Serif
import com.trillix.witnessed.ui.theme.Surface3
import com.trillix.witnessed.ui.theme.TextMain

@Composable
fun SettingsScreen(state: UiState, vm: AppViewModel) {
    val app = state.app ?: return
    var editingPromise by remember { mutableStateOf(false) }
    var draftPromise by remember(app.promiseText) { mutableStateOf(app.promiseText) }
    var confirmReset by remember { mutableStateOf(false) }

    val notifPreview = when (app.mode) {
        Mode.LIGHT -> "You had 6 temptation moments today. Want to see the pattern?"
        Mode.SERIOUS -> "You continued 4 times today. Want the receipts?"
        Mode.NOBULL -> "${app.appName} ran your evening again. Look at the pattern."
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp)) {

        Section("Your promise") {
            Card {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(30.dp).clip(RoundedCornerShape(8.dp)).background(Color(app.appColor)),
                        contentAlignment = Alignment.Center) {
                        Text(app.appGlyph, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(app.appName, color = TextMain, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                        Tiny("Watching · recovering ${OUTCOME_OPTS.firstOrNull { it.id == app.desiredOutcome }?.name ?: "your time"}")
                    }
                }
                Spacer(Modifier.height(12.dp))
                if (editingPromise) {
                    LedgerField(draftPromise, { if (it.length <= 140) draftPromise = it }, minLines = 3, fontSize = 15)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                        QuietButton("Cancel", modifier = Modifier.weight(1f)) {
                            draftPromise = app.promiseText; editingPromise = false
                        }
                        PrimaryButton("Save", modifier = Modifier.weight(1f)) {
                            val v = draftPromise.trim().ifEmpty { app.promiseText }
                            vm.updateApp { it.copy(promiseText = v) }
                            editingPromise = false
                        }
                    }
                } else {
                    Text("“${app.promiseText}”", color = TextMain, fontFamily = Serif, fontStyle = FontStyle.Italic,
                        fontSize = 16.sp, lineHeight = 22.sp)
                    Spacer(Modifier.height(12.dp))
                    QuietButton("Edit promise") { draftPromise = app.promiseText; editingPromise = true }
                }
            }
        }

        Section("Accountability level", note = "Switch any time. The wall and your mirror change with it.") {
            MODE_INFO.values.forEach { m ->
                val sel = app.mode == m.mode
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp))
                        .background(if (sel) AccentSoft else com.trillix.witnessed.ui.theme.Surface1)
                        .border(1.dp, if (sel) AccentLine else Line, RoundedCornerShape(15.dp))
                        .clickable { vm.updateApp { it.copy(mode = m.mode) } }
                        .padding(horizontal = 17.dp, vertical = 16.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(m.glyph, color = AccentText, fontSize = 13.sp)
                        Spacer(Modifier.width(9.dp))
                        Text(m.name, color = TextMain, fontFamily = Sans, fontWeight = FontWeight.Bold, fontSize = 16.sp,
                            modifier = Modifier.weight(1f))
                        if (sel) VIcon("check", size = 18.dp, color = AccentText, sw = 2.2f)
                    }
                    Spacer(Modifier.height(5.dp))
                    Text("“${m.line}”", color = AccentText, fontFamily = Serif, fontStyle = FontStyle.Italic, fontSize = 15.sp)
                }
                Spacer(Modifier.height(10.dp))
            }
        }

        Section("Tone of voice", note = "How Witnessed speaks to you on the wall and in notifications.") {
            Segmented(
                options = Tone.values().map { it to (TONE_NAME[it] ?: it.name) },
                selected = app.tone,
                onSelect = { vm.updateApp { a -> a.copy(tone = it) } },
            )
        }

        Section("Detection", note = "The promise works at every level. Heavier detection is always opt-in.") {
            listOf(
                Triple(DetectionTier.MANUAL, "Manual", "You log moments yourself · no permissions"),
                Triple(DetectionTier.USAGE, "Usage access", "Objective minutes · on-return mirror"),
                Triple(DetectionTier.ACCESSIBILITY, "Full effect", "Real-time wall · Accessibility + overlay"),
            ).forEach { (tier, name, sub) ->
                val sel = state.settings.detection == tier
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                        .background(if (sel) AccentSoft else com.trillix.witnessed.ui.theme.Surface1)
                        .border(1.dp, if (sel) AccentLine else Line, RoundedCornerShape(14.dp))
                        .clickable { vm.setDetection(tier) }
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(name, color = TextMain, fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 16.sp)
                        Tiny(sub)
                    }
                    if (sel) VIcon("check", size = 20.dp, color = AccentText, sw = 2.2f)
                }
                Spacer(Modifier.height(9.dp))
            }
        }

        Section("Notifications") {
            Card {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(30.dp).clip(RoundedCornerShape(8.dp)).background(Surface3),
                        contentAlignment = Alignment.Center) { VIcon("bell", size = 16.dp, color = AccentText) }
                    Spacer(Modifier.width(11.dp))
                    Text("“$notifPreview”", color = Dim, fontSize = 13.5.sp, lineHeight = 19.sp)
                }
            }
            Spacer(Modifier.height(12.dp))
            ToggleRow("Daily mirror summary", state.settings.dailySummary) { vm.setDaily(it) }
            ToggleRow("Weekly pattern report", state.settings.weeklySummary) { vm.setWeekly(it) }
        }

        Section("Privacy") {
            Card(strong = true) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    VIcon("door", size = 20.dp, color = AccentText)
                    Spacer(Modifier.width(10.dp))
                    Text("We see the door, not the room.", color = TextMain, fontFamily = Serif,
                        fontStyle = FontStyle.Italic, fontSize = 16.sp)
                }
                Spacer(Modifier.height(12.dp))
                PrivacyLine("Kept on this phone", "app you chose · timestamps · your choice · reasons · promise", Kept)
                Spacer(Modifier.height(12.dp))
                PrivacyLine("Never touched", "messages · screen content · keystrokes · other apps · your activity inside any app", Faint)
            }
        }

        Section("Data", note = "Your receipts are yours. Clearing and resetting are one tap — never buried.") {
            QuietButton("Reload a sample week") { vm.reseed() }
            Spacer(Modifier.height(9.dp))
            QuietButton("Clear all receipts") { vm.clearReceipts() }
            Spacer(Modifier.height(9.dp))
            if (!confirmReset) {
                GhostButton("Reset everything") { confirmReset = true }
            } else {
                Card(accent = true) {
                    Text("Delete your promise, receipts and settings? This can’t be undone.",
                        color = TextMain, fontSize = 14.sp, lineHeight = 20.sp)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                        QuietButton("Keep it", modifier = Modifier.weight(1f)) { confirmReset = false }
                        PrimaryButton("Delete all", modifier = Modifier.weight(1f)) { vm.resetAll() }
                    }
                }
            }
        }

        Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Seal(size = 26.dp)
                Spacer(Modifier.height(6.dp))
                Tiny("Witnessed · a Trillix product · not therapy or medical treatment", align = TextAlign.Center)
            }
        }
    }
}

@Composable
private fun Section(label: String, note: String? = null, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(bottom = 26.dp)) {
        Kicker(label)
        Spacer(Modifier.height(12.dp))
        content()
        if (note != null) {
            Spacer(Modifier.height(10.dp))
            Tiny(note)
        }
    }
}

@Composable
private fun ToggleRow(label: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().border(1.dp, Line, RoundedCornerShape(0.dp)).padding(vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, color = TextMain, fontSize = 15.sp, modifier = Modifier.weight(1f))
        SwitchToggle(on, onChange)
    }
}

@Composable
private fun SwitchToggle(on: Boolean, onChange: (Boolean) -> Unit) {
    val knob by animateDpAsState(if (on) 21.dp else 3.dp, label = "knob")
    Box(
        Modifier.width(46.dp).height(28.dp).clip(RoundedCornerShape(99.dp))
            .background(if (on) Accent else Surface3).clickable { onChange(!on) },
    ) {
        Box(
            Modifier.padding(start = knob, top = 3.dp).size(22.dp).clip(RoundedCornerShape(99.dp))
                .background(if (on) OnAccent else Color(0xFF8C8576)),
        )
    }
}

@Composable
private fun <T> Segmented(options: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Bg2)
            .border(1.dp, Line, RoundedCornerShape(12.dp)).padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        options.forEach { (value, label) ->
            val sel = value == selected
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(9.dp))
                    .background(if (sel) Surface3 else Color.Transparent)
                    .clickable { onSelect(value) }.padding(vertical = 9.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(label, color = if (sel) TextMain else Dim, fontFamily = Sans,
                    fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun PrivacyLine(head: String, body: String, headColor: Color) {
    Column {
        Text(head.uppercase(), color = headColor, fontFamily = Mono, fontSize = 10.5.sp, letterSpacing = 1.sp)
        Spacer(Modifier.height(4.dp))
        Text(body, color = Dim, fontSize = 13.sp, lineHeight = 19.sp)
    }
}
