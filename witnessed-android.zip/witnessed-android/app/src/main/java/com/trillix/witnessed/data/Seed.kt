package com.trillix.witnessed.data
// Intentionally empty: the app no longer fabricates sample data.
// Every receipt in the ledger is a real logged moment.
