package com.trillix.witnessed.data

import java.util.Calendar
import kotlin.random.Random

/** Builds a realistic ~week of receipts so the Mirror has a pattern to show. */
fun seedReceipts(app: WatchedApp, now: Long = System.currentTimeMillis()): List<AttemptReceipt> {
    val day = 86_400_000L
    val hourPool = intArrayOf(
        9, 10, 10, 11, 11, 12, 13, 14, 14, 15, 15, 16, 16,   // work block
        19, 20, 21, 21, 22, 22, 22, 23, 23, 23, 0,           // evening danger window
        8, 12, 17, 18,                                       // scattered
    )
    val reasonPool = arrayOf(
        "bored", "bored", "bored", "bored", "bored", "habit", "habit",
        "stressed", "stressed", "avoiding", "lonely", "nocare"
    )
    val out = ArrayList<AttemptReceipt>()
    repeat(37) {
        val dayBack = Random.nextInt(7)
        val hour = hourPool[Random.nextInt(hourPool.size)]
        val cal = Calendar.getInstance().apply {
            timeInMillis = now - dayBack * day
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, Random.nextInt(60))
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        var ts = cal.timeInMillis
        if (ts > now) ts = now - (Random.nextDouble() * 3_600_000).toLong()
        val backed = Random.nextDouble() < 0.41
        val reason = if (backed) null else reasonPool[Random.nextInt(reasonPool.size)]
        val h = Calendar.getInstance().apply { timeInMillis = ts }.get(Calendar.HOUR_OF_DAY)
        out.add(
            AttemptReceipt(
                watchedAppId = app.id,
                timestamp = ts,
                hour = h,
                outcome = if (backed) Outcome.BACKED_OUT else Outcome.CONTINUED,
                reasonCategory = reason,
                reasonText = null,
                modeAtTime = app.mode,
                promiseAtTime = app.promiseText,
                seeded = true,
            )
        )
    }
    return out.sortedByDescending { it.timestamp }
}
