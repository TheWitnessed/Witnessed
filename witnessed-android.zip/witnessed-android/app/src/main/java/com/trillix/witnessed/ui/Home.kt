package com.trillix.witnessed.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.trillix.witnessed.data.MODE_INFO
import com.trillix.witnessed.data.Mode
import com.trillix.witnessed.data.reasonName
import com.trillix.witnessed.ui.theme.Accent
import com.trillix.witnessed.ui.theme.AccentLine
import com.trillix.witnessed.ui.theme.AccentSoft
import com.trillix.witnessed.ui.theme.AccentText
import com.trillix.witnessed.ui.theme.Bg
import com.trillix.witnessed.ui.theme.Bg2
import com.trillix.witnessed.ui.theme.Dim
import com.trillix.witnessed.ui.theme.Faint
import com.trillix.witnessed.ui.theme.Kept
import com.trillix.witnessed.ui.theme.Line
import com.trillix.witnessed.ui.theme.LineStrong
import com.trillix.witnessed.ui.theme.Mono
import com.trillix.witnessed.ui.theme.Serif
import com.trillix.witnessed.ui.theme.Surface1
import com.trillix.witnessed.ui.theme.Surface3
import com.trillix.witnessed.ui.theme.TextMain

private fun lvl(mode: Mode) = when (mode) { Mode.LIGHT -> 0; Mode.SERIOUS -> 1; Mode.NOBULL -> 2 }

@Composable
fun HomeScreen(state: UiState, vm: AppViewModel, onTrigger: () -> Unit) {
    var tab by remember { mutableStateOf("mirror") }
    val titles = mapOf("mirror" to "Mirror", "receipts" to "Receipts", "settings" to "Settings")

    Column(Modifier.fillMaxSize().background(Bg)) {
        // app bar
        Row(
            Modifier.fillMaxWidth().border(1.dp, Line, RoundedCornerShape(0.dp))
                .padding(horizontal = 18.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(titles[tab] ?: "", color = TextMain, fontFamily = Serif, fontWeight = FontWeight.Medium,
                fontSize = 19.sp, modifier = Modifier.weight(1f))
            Seal(size = 26.dp)
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (tab) {
                "mirror" -> Mirror(state, onTrigger)
                "receipts" -> Receipts(state)
                else -> SettingsScreen(state, vm)
            }
        }

        // bottom nav
        Row(Modifier.fillMaxWidth().background(Bg2).border(1.dp, Line, RoundedCornerShape(0.dp))) {
            listOf(
                Triple("mirror", "mirror", "Mirror"),
                Triple("receipts", "receipt", "Receipts"),
                Triple("settings", "gear", "Settings"),
            ).forEach { (id, icon, label) ->
                val on = tab == id
                Column(
                    Modifier.weight(1f).clickable { tab = id }.padding(top = 11.dp, bottom = 13.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    VIcon(icon, size = 21.dp, color = if (on) AccentText else Faint)
                    Spacer(Modifier.height(5.dp))
                    Text(label, color = if (on) AccentText else Faint, fontFamily = com.trillix.witnessed.ui.theme.Sans,
                        fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun Mirror(state: UiState, onTrigger: () -> Unit) {
    val app = state.app ?: return
    val stats = state.stats ?: return
    val l = lvl(app.mode)
    val w = stats.week
    val t = stats.today
    val hasData = state.receipts.isNotEmpty()

    val reasonLc = w.topReason?.lowercase()
    val summary = when {
        !hasData -> ""
        app.mode == Mode.LIGHT ->
            "You had ${w.total} temptation ${if (w.total == 1) "moment" else "moments"} this week. You backed out ${w.backed} of them."
        else ->
            "You reached for ${app.appName} ${w.total} times this week. ${w.workHours} happened during work hours. " +
                (reasonLc?.let { "Your most common reason was $it. " } ?: "") +
                "You kept your promise ${w.keptPct}% of the time."
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        // promise banner
        Column(Modifier.padding(horizontal = 22.dp).padding(top = 16.dp)) {
            Card(accent = true) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(26.dp).clip(RoundedCornerShape(7.dp)).background(Color(app.appColor)),
                        contentAlignment = Alignment.Center,
                    ) { Text(app.appGlyph, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.width(9.dp))
                    Text("YOUR PROMISE · ${MODE_INFO[app.mode]?.name} MODE", color = Dim, fontFamily = Mono,
                        fontSize = 10.5.sp, letterSpacing = 1.4.sp)
                }
                Spacer(Modifier.height(9.dp))
                PromiseQuote(app.promiseText, size = 18)
            }
        }

        Column(Modifier.padding(22.dp)) {
            if (!hasData) {
                Column(Modifier.fillMaxWidth().padding(vertical = 30.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier.size(54.dp).clip(RoundedCornerShape(14.dp)).border(1.dp, LineStrong, RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center,
                    ) { VIcon("receipt", size = 24.dp, color = Dim) }
                    Spacer(Modifier.height(14.dp))
                    Text("No receipts yet.", color = TextMain, fontFamily = Serif, fontWeight = FontWeight.Medium, fontSize = 22.sp)
                    Spacer(Modifier.height(6.dp))
                    Lead("The first time you feel the pull, log it. The pattern builds itself.")
                }
            } else {
                Kicker("Today")
                Spacer(Modifier.height(11.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    StatTile(t.total.toString(), "Attempts", modifier = Modifier.weight(1f))
                    StatTile(t.backed.toString(), "Backed out", accent = true, modifier = Modifier.weight(1f))
                    if (l >= 1) StatTile(t.cont.toString(), "Continued", modifier = Modifier.weight(1f))
                }
                Spacer(Modifier.height(22.dp))

                Kicker("This week")
                Spacer(Modifier.height(11.dp))
                Card {
                    Text(summary, color = TextMain, fontFamily = Serif, fontSize = 17.sp, lineHeight = 24.sp)
                }
                Spacer(Modifier.height(14.dp))

                if (l >= 1) {
                    Card {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Kicker("Promise kept", modifier = Modifier.weight(1f))
                            Text("${w.keptPct}%", color = Kept, fontFamily = Serif, fontSize = 22.sp)
                        }
                        Spacer(Modifier.height(10.dp))
                        Meter(w.keptPct)
                        Spacer(Modifier.height(9.dp))
                        Tiny("${w.backed} backed out · ${w.cont} continued · ${w.total} total moments")
                    }
                    Spacer(Modifier.height(14.dp))
                }

                if (l >= 1 && w.reasonCounts.isNotEmpty()) {
                    Card {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Kicker("Why you continued", modifier = Modifier.weight(1f))
                            w.topReason?.let { Tag("Top · $it") }
                        }
                        Spacer(Modifier.height(14.dp))
                        ReasonBars(w.reasonCounts)
                    }
                    Spacer(Modifier.height(14.dp))
                }

                if (l >= 2) {
                    Card {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Kicker("Danger window", modifier = Modifier.weight(1f))
                            Tag(w.dangerWindow)
                        }
                        Spacer(Modifier.height(14.dp))
                        DangerSpark(w.hist, w.worstStart)
                        Spacer(Modifier.height(12.dp))
                        Tiny("You don’t open it randomly. Your heaviest pull lands between ${w.dangerWindow}. Earliest ${w.earliest} · latest ${w.latest}.")
                    }
                    Spacer(Modifier.height(14.dp))
                }
            }

            Spacer(Modifier.height(8.dp))
            PrimaryButton("I’m being pulled — log it", icon = "hand", onClick = onTrigger)
            Spacer(Modifier.height(10.dp))
            Tiny(
                when (state.settings.detection) {
                    com.trillix.witnessed.data.DetectionTier.MANUAL -> "Manual mode: you keep the receipts yourself."
                    com.trillix.witnessed.data.DetectionTier.USAGE -> "Usage access on — minutes are recorded objectively."
                    else -> "Full effect on — the wall appears the moment you open ${app.appName}."
                },
                modifier = Modifier.fillMaxWidth(), align = TextAlign.Center,
            )
        }
    }
}

@Composable
private fun Tag(text: String) {
    Box(
        Modifier.clip(RoundedCornerShape(6.dp)).background(AccentSoft)
            .border(1.dp, AccentLine, RoundedCornerShape(6.dp)).padding(horizontal = 8.dp, vertical = 4.dp),
    ) { Text(text.uppercase(), color = AccentText, fontFamily = Mono, fontSize = 10.5.sp, letterSpacing = 0.8.sp) }
}

@Composable
private fun ReasonBars(counts: Map<String, Int>) {
    val entries = counts.entries.sortedByDescending { it.value }
    val max = (entries.maxOfOrNull { it.value } ?: 1).coerceAtLeast(1)
    Column {
        entries.forEach { (id, n) ->
            Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(reasonName(id) ?: id, color = Dim, fontSize = 13.sp, modifier = Modifier.width(82.dp))
                Spacer(Modifier.width(12.dp))
                Box(Modifier.weight(1f).height(8.dp).clip(RoundedCornerShape(99.dp)).background(Surface3)) {
                    Box(Modifier.fillMaxWidth(fraction = n.toFloat() / max).height(8.dp).clip(RoundedCornerShape(99.dp)).background(Accent))
                }
                Spacer(Modifier.width(12.dp))
                Text(n.toString(), color = Faint, fontFamily = Mono, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun DangerSpark(hist: List<Int>, worstStart: Int) {
    val max = (hist.maxOrNull() ?: 1).coerceAtLeast(1)
    val window = setOf(worstStart, (worstStart + 1) % 24, (worstStart + 2) % 24)
    Row(Modifier.fillMaxWidth().height(46.dp), verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        hist.forEachIndexed { h, v ->
            val barH: Dp = ((v.toFloat() / max) * 46f).dp.coerceAtLeast(2.dp)
            val c = if (h in window) Accent else if (v > 0) AccentLine else Surface3
            Box(Modifier.weight(1f).height(barH).clip(RoundedCornerShape(topStart = 2.dp, topEnd = 2.dp)).background(c))
        }
    }
    Row(Modifier.fillMaxWidth().padding(top = 7.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        listOf("12a", "6a", "12p", "6p").forEach {
            Text(it, color = Faint, fontFamily = Mono, fontSize = 9.5.sp)
        }
    }
}
