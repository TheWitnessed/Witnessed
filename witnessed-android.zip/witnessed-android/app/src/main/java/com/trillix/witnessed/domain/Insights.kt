package com.trillix.witnessed.domain

import com.trillix.witnessed.data.AttemptReceipt
import com.trillix.witnessed.data.Outcome
import com.trillix.witnessed.data.reasonName
import java.util.Calendar

data class DayStats(
    val total: Int,
    val backed: Int,
    val cont: Int,
    val topReason: String?,
)

data class WeekStats(
    val total: Int,
    val backed: Int,
    val cont: Int,
    val keptPct: Int,
    val topReason: String?,
    val dangerWindow: String,
    val workHours: Int,
    val hist: List<Int>,
    val reasonCounts: Map<String, Int>,
    val earliest: String,
    val latest: String,
    val worstStart: Int,
)

data class Stats(
    val today: DayStats,
    val week: WeekStats,
    val latest: AttemptReceipt?,
)

/** Pure stat functions over the receipt ledger — ported from computeStats(). */
object Insights {
    fun compute(receipts: List<AttemptReceipt>, now: Long = System.currentTimeMillis()): Stats {
        val startToday = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val weekAgo = now - 7L * 86_400_000L

        val week = receipts.filter { it.timestamp >= weekAgo }
        val today = receipts.filter { it.timestamp >= startToday }
        fun count(list: List<AttemptReceipt>, o: Outcome) = list.count { it.outcome == o }

        val wBacked = count(week, Outcome.BACKED_OUT)
        val wCont = count(week, Outcome.CONTINUED)
        val wTotal = week.size
        val keptPct = if (wTotal > 0) Math.round(wBacked * 100f / wTotal) else 0

        val reasonCounts = HashMap<String, Int>()
        week.forEach { r -> r.reasonCategory?.let { reasonCounts[it] = (reasonCounts[it] ?: 0) + 1 } }
        val topReason = reasonName(reasonCounts.entries.maxByOrNull { it.value }?.key)

        val hist = IntArray(24)
        week.forEach { if (it.hour in 0..23) hist[it.hour] = hist[it.hour] + 1 }
        var worstStart = 0
        var worstSum = -1
        for (h in 0 until 24) {
            val sum = hist[h] + hist[(h + 1) % 24] + hist[(h + 2) % 24]
            if (sum > worstSum) { worstSum = sum; worstStart = h }
        }
        fun fmtH(h: Int): String {
            val hh = ((h % 24) + 24) % 24
            val ap = if (hh < 12) "am" else "pm"
            var v = hh % 12; if (v == 0) v = 12
            return "$v$ap"
        }
        val dangerWindow = if (wTotal > 0) "${fmtH(worstStart)}–${fmtH(worstStart + 3)}" else "—"
        val workHours = week.count { it.hour in 9..16 }

        fun fmtTime(r: AttemptReceipt): String {
            val c = Calendar.getInstance().apply { timeInMillis = r.timestamp }
            val h = c.get(Calendar.HOUR_OF_DAY)
            val m = c.get(Calendar.MINUTE)
            val ap = if (h < 12) "AM" else "PM"
            var hh = h % 12; if (hh == 0) hh = 12
            return String.format("%d:%02d %s", hh, m, ap)
        }
        val byHour = week.sortedBy { it.hour }
        val earliest = byHour.firstOrNull()?.let { fmtTime(it) } ?: "—"
        val latest = byHour.lastOrNull()?.let { fmtTime(it) } ?: "—"

        val tReasonCounts = HashMap<String, Int>()
        today.forEach { r -> r.reasonCategory?.let { tReasonCounts[it] = (tReasonCounts[it] ?: 0) + 1 } }
        val tTop = reasonName(tReasonCounts.entries.maxByOrNull { it.value }?.key)

        return Stats(
            today = DayStats(today.size, count(today, Outcome.BACKED_OUT), count(today, Outcome.CONTINUED), tTop),
            week = WeekStats(
                wTotal, wBacked, wCont, keptPct, topReason, dangerWindow, workHours,
                hist.toList(), reasonCounts, earliest, latest, worstStart
            ),
            latest = receipts.firstOrNull(),
        )
    }
}
