package com.trillix.witnessed.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "witnessed_settings")

data class UserSettings(
    val onboardingComplete: Boolean = false,
    val dailySummary: Boolean = true,
    val weeklySummary: Boolean = true,
    val privacyLock: Boolean = false,
    val detection: DetectionTier = DetectionTier.MANUAL,
)

class SettingsStore(private val context: Context) {
    private object Keys {
        val onboarding = booleanPreferencesKey("onboarding_complete")
        val daily = booleanPreferencesKey("daily_summary")
        val weekly = booleanPreferencesKey("weekly_summary")
        val privacy = booleanPreferencesKey("privacy_lock")
        val detection = stringPreferencesKey("detection")
    }

    val flow: Flow<UserSettings> = context.dataStore.data.map { p ->
        UserSettings(
            onboardingComplete = p[Keys.onboarding] ?: false,
            dailySummary = p[Keys.daily] ?: true,
            weeklySummary = p[Keys.weekly] ?: true,
            privacyLock = p[Keys.privacy] ?: false,
            detection = p[Keys.detection]
                ?.let { runCatching { DetectionTier.valueOf(it) }.getOrNull() }
                ?: DetectionTier.MANUAL,
        )
    }

    suspend fun setOnboardingComplete(v: Boolean) =
        edit { it[Keys.onboarding] = v }
    suspend fun setDaily(v: Boolean) = edit { it[Keys.daily] = v }
    suspend fun setWeekly(v: Boolean) = edit { it[Keys.weekly] = v }
    suspend fun setPrivacy(v: Boolean) = edit { it[Keys.privacy] = v }
    suspend fun setDetection(v: DetectionTier) = edit { it[Keys.detection] = v.name }
    suspend fun clear() = edit { it.clear() }

    private suspend fun edit(block: (androidx.datastore.preferences.core.MutablePreferences) -> Unit) {
        context.dataStore.edit(block)
    }
}
