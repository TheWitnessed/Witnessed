package com.trillix.witnessed.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.trillix.witnessed.ui.theme.Accent
import com.trillix.witnessed.ui.theme.Faint
import com.trillix.witnessed.ui.theme.LineStrong
import com.trillix.witnessed.ui.theme.Serif
import com.trillix.witnessed.ui.theme.Surface1
import com.trillix.witnessed.ui.theme.TextMain

/** Serif multi-line text field, styled like the prototype's .field. */
@Composable
fun LedgerField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    placeholder: String = "",
    minLines: Int = 3,
    fontSize: Int = 17,
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(13.dp))
            .background(Surface1)
            .border(1.dp, LineStrong, RoundedCornerShape(13.dp))
            .padding(horizontal = 16.dp, vertical = 15.dp),
    ) {
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            textStyle = TextStyle(
                color = TextMain,
                fontFamily = Serif,
                fontSize = fontSize.sp,
                lineHeight = (fontSize * 1.4f).sp,
            ),
            cursorBrush = SolidColor(Accent),
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = (minLines * 24).dp),
            decorationBox = { inner ->
                if (value.isEmpty()) {
                    Text(
                        placeholder,
                        color = Faint,
                        fontFamily = Serif,
                        fontStyle = FontStyle.Italic,
                        fontSize = fontSize.sp,
                    )
                }
                inner()
            },
        )
    }
}
