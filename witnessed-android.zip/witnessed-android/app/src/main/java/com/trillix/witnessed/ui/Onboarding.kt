package com.trillix.witnessed.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.trillix.witnessed.data.CONTROL_OPTS
import com.trillix.witnessed.data.DetectionTier
import com.trillix.witnessed.data.MODE_INFO
import com.trillix.witnessed.data.Mode
import com.trillix.witnessed.data.OUTCOME_OPTS
import com.trillix.witnessed.data.Option
import com.trillix.witnessed.data.PROMISE_EXAMPLES
import com.trillix.witnessed.data.Tone
import com.trillix.witnessed.data.WatchedApp
import com.trillix.witnessed.ui.theme.Accent
import com.trillix.witnessed.ui.theme.AccentLine
import com.trillix.witnessed.ui.theme.AccentSoft
import com.trillix.witnessed.ui.theme.AccentText
import com.trillix.witnessed.ui.theme.Bg
import com.trillix.witnessed.ui.theme.Dim
import com.trillix.witnessed.ui.theme.Faint
import com.trillix.witnessed.ui.theme.KeptSoft
import com.trillix.witnessed.ui.theme.Line
import com.trillix.witnessed.ui.theme.LineStrong
import com.trillix.witnessed.ui.theme.Mono
import com.trillix.witnessed.ui.theme.Sans
import com.trillix.witnessed.ui.theme.Serif
import com.trillix.witnessed.ui.theme.Surface1
import com.trillix.witnessed.ui.theme.Surface3
import com.trillix.witnessed.ui.theme.TextMain

private data class OnbDraft(
    val appId: String? = null,
    val appName: String? = null,
    val appColor: Long = 0xFF343126,
    val appGlyph: String = "",
    val outcome: String? = null,
    val promise: String = "",
    val mode: Mode = Mode.SERIOUS,
    val tone: Tone = Tone.DIRECT,
    val detection: DetectionTier = DetectionTier.MANUAL,
)

@Composable
fun Onboarding(onComplete: (WatchedApp, DetectionTier) -> Unit) {
    var step by remember { mutableStateOf(-1) }
    var d by remember { mutableStateOf(OnbDraft()) }
    val total = 6

    when (step) {
        -1 -> WelcomeScreen(onStart = { step = 0 })

        0 -> OnbShell(0, total, onBack = { step = -1 },
            footerEnabled = d.appId != null, footerText = "Continue", onNext = { step = 1 }) {
            Kicker("Step one")
            Spacer(Modifier.height(10.dp))
            H1("What keeps pulling you back?")
            Spacer(Modifier.height(6.dp))
            Lead("Pick the one that costs you the most. You can change it later.")
            Spacer(Modifier.height(18.dp))
            CONTROL_OPTS.forEach { o ->
                OptionRow(o, selected = d.appId == o.id) {
                    d = d.copy(appId = o.id, appName = o.name, appColor = o.color, appGlyph = o.glyph)
                }
                Spacer(Modifier.height(9.dp))
            }
        }

        1 -> OnbShell(1, total, onBack = { step = 0 },
            footerEnabled = d.outcome != null, footerText = "Continue", onNext = { step = 2 }) {
            Kicker("Step two")
            Spacer(Modifier.height(10.dp))
            H1("What do you want back?")
            Spacer(Modifier.height(6.dp))
            Lead("You’re not blocking an app. You’re recovering something.")
            Spacer(Modifier.height(18.dp))
            // 2-column grid of outcomes
            val rows = OUTCOME_OPTS.chunked(2)
            rows.forEach { pair ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    pair.forEach { o ->
                        Box(
                            Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (d.outcome == o.id) AccentSoft else Surface1)
                                .border(1.dp, if (d.outcome == o.id) AccentLine else Line, RoundedCornerShape(14.dp))
                                .clickable { d = d.copy(outcome = o.id) }
                                .padding(vertical = 17.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(o.name, color = TextMain, fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 16.sp)
                        }
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
                Spacer(Modifier.height(9.dp))
            }
        }

        2 -> {
            val outcomeName = OUTCOME_OPTS.firstOrNull { it.id == d.outcome }?.name?.lowercase()
            OnbShell(2, total, onBack = { step = 1 },
                footerEnabled = d.promise.trim().length >= 4, footerText = "This is my promise",
                footerNote = "You’ll see these exact words at the moment of temptation.",
                onNext = { step = 3 }) {
                Kicker("Step three · the promise")
                Spacer(Modifier.height(10.dp))
                H1("What do you want future-you to remember?")
                Spacer(Modifier.height(6.dp))
                Lead("One honest sentence. Write it the way you’d want to hear it.")
                Spacer(Modifier.height(16.dp))
                LedgerField(
                    value = d.promise,
                    onValueChange = { if (it.length <= 140) d = d.copy(promise = it) },
                    placeholder = outcomeName?.let { "e.g. I said I wanted my $it back." }
                        ?: "e.g. I said I wanted my evenings back.",
                    minLines = 3,
                )
                Spacer(Modifier.height(6.dp))
                Text("${d.promise.length}/140", color = Faint, fontFamily = Mono, fontSize = 11.sp,
                    modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End)
                Spacer(Modifier.height(18.dp))
                Kicker("Borrow a line")
                Spacer(Modifier.height(10.dp))
                PROMISE_EXAMPLES.forEach { ex ->
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Surface1)
                            .border(1.dp, Line, RoundedCornerShape(14.dp))
                            .clickable { d = d.copy(promise = ex) }
                            .padding(horizontal = 15.dp, vertical = 13.dp),
                    ) {
                        Text(ex, color = TextMain, fontFamily = Serif, fontStyle = FontStyle.Italic, fontSize = 15.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }
        }

        3 -> OnbShell(3, total, onBack = { step = 2 },
            footerEnabled = true, footerText = "Continue", onNext = { step = 4 }) {
            Kicker("Step four")
            Spacer(Modifier.height(10.dp))
            H1("How much accountability do you actually want?")
            Spacer(Modifier.height(6.dp))
            Lead("You can change this any time. Start where you’ll actually keep going.")
            Spacer(Modifier.height(18.dp))
            MODE_INFO.values.forEach { m ->
                ModeCard(
                    selected = d.mode == m.mode,
                    onClick = { d = d.copy(mode = m.mode) },
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(m.glyph, color = AccentText, fontSize = 13.sp)
                        Spacer(Modifier.width(9.dp))
                        Text(m.name, color = TextMain, fontFamily = Sans, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    Spacer(Modifier.height(5.dp))
                    Text("“${m.line}”", color = AccentText, fontFamily = Serif, fontStyle = FontStyle.Italic, fontSize = 15.sp)
                    Spacer(Modifier.height(9.dp))
                    Text(m.desc, color = Dim, fontSize = 12.5.sp, lineHeight = 18.sp)
                }
                Spacer(Modifier.height(11.dp))
            }
        }

        4 -> OnbShell(4, total, onBack = { step = 3 },
            footerEnabled = true, footerText = "I understand", onNext = { step = 5 }) {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Box(
                    Modifier.size(56.dp).clip(RoundedCornerShape(16.dp)).background(Surface1)
                        .border(1.dp, LineStrong, RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center,
                ) { VIcon("door", size = 26.dp, color = AccentText) }
            }
            Spacer(Modifier.height(14.dp))
            H1("We see the door, not the room.", modifier = Modifier.fillMaxWidth(), size = 26)
            Spacer(Modifier.height(6.dp))
            Lead("Witnessed only notices the opening of the app you chose — so it can show your promise at the right moment.")
            Spacer(Modifier.height(20.dp))
            Card(strong = true) {
                Kicker("Witnessed never")
                Spacer(Modifier.height(12.dp))
                listOf(
                    "read your messages", "see your screen content", "record what you type",
                    "track apps you didn’t choose", "watch what happens inside any app",
                ).forEach { n ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        VIcon("close", size = 15.dp, color = Faint, sw = 2f)
                        Spacer(Modifier.width(11.dp))
                        Text(n, color = Dim, fontSize = 14.5.sp)
                    }
                    Spacer(Modifier.height(11.dp))
                }
            }
            Spacer(Modifier.height(16.dp))
            Tiny("Everything stays on this phone. Witnessed is not therapy or medical treatment.",
                modifier = Modifier.fillMaxWidth(), align = TextAlign.Center)
        }

        else -> {
            val tiers = listOf(
                Triple(DetectionTier.MANUAL, "Start light",
                    "You log the moment yourself with one tap, and get danger-window nudges. Nothing to enable. Works today."),
                Triple(DetectionTier.USAGE, "Add the objective record",
                    "Witnessed reads how long the chosen app ran — for honest minutes and on-return receipts. One toggle in Settings."),
                Triple(DetectionTier.ACCESSIBILITY, "Full effect",
                    "The real-time wall: your promise appears the instant you open the app — before you scroll. Strongest, fully optional."),
            )
            OnbShell(5, total, onBack = { step = 4 },
                footerEnabled = true,
                footerText = if (d.detection == DetectionTier.MANUAL) "Start without permissions" else "Continue",
                footerNote = "You can change this any time. Witnessed works even with nothing enabled.",
                onNext = {
                    onComplete(
                        WatchedApp(
                            id = 1,
                            packageName = null,
                            appName = d.appName ?: "Something",
                            appColor = d.appColor,
                            appGlyph = d.appGlyph,
                            enabled = true,
                            createdAt = System.currentTimeMillis(),
                            mode = d.mode,
                            promiseText = d.promise.trim().ifEmpty { "I said I wanted my evenings back." },
                            desiredOutcome = d.outcome ?: "time",
                            tone = d.tone,
                        ),
                        d.detection,
                    )
                }) {
                Kicker("Step five · detection")
                Spacer(Modifier.height(10.dp))
                H1("Pick your level.")
                Spacer(Modifier.height(6.dp))
                Lead("The promise works at every level. Heavier detection is always your choice.")
                Spacer(Modifier.height(18.dp))
                tiers.forEachIndexed { i, (tier, name, desc) ->
                    val icon = when (tier) {
                        DetectionTier.MANUAL -> "hand"; DetectionTier.USAGE -> "clock"; else -> "shield"
                    }
                    ModeCard(selected = d.detection == tier, onClick = { d = d.copy(detection = tier) }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(34.dp).clip(RoundedCornerShape(9.dp)).background(Surface3),
                                contentAlignment = Alignment.Center,
                            ) { VIcon(icon, size = 18.dp, color = AccentText) }
                            Spacer(Modifier.width(11.dp))
                            Text(name, color = TextMain, fontFamily = Sans, fontWeight = FontWeight.Bold, fontSize = 15.5.sp,
                                modifier = Modifier.weight(1f))
                            if (i == 0) {
                                Box(
                                    Modifier.clip(RoundedCornerShape(6.dp)).background(KeptSoft)
                                        .padding(horizontal = 8.dp, vertical = 4.dp),
                                ) { Text("RECOMMENDED", color = com.trillix.witnessed.ui.theme.Kept, fontFamily = Mono, fontSize = 9.5.sp) }
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Text(desc, color = Dim, fontSize = 12.5.sp, lineHeight = 18.sp)
                    }
                    Spacer(Modifier.height(11.dp))
                }
            }
        }
    }
}

@Composable
private fun WelcomeScreen(onStart: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 26.dp, vertical = 46.dp),
    ) {
        Seal(size = 62.dp)
        Spacer(Modifier.height(26.dp))
        Kicker("A private behaviour ledger")
        Spacer(Modifier.height(16.dp))
        H1("Catch yourself before autopilot takes over.", size = 34)
        Spacer(Modifier.height(18.dp))
        Text(
            "Write a promise to yourself. When temptation hits, Witnessed shows it back to you — and keeps the receipt.",
            color = Dim, fontSize = 16.sp, lineHeight = 24.sp,
        )
        Spacer(Modifier.height(40.dp))
        PrimaryButton("Start with one promise", onClick = onStart)
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            VIcon("shield", size = 15.dp, color = Faint)
            Spacer(Modifier.width(8.dp))
            Tiny("Private by design. We track the moment, not the inside.")
        }
    }
}

@Composable
private fun OnbShell(
    step: Int,
    total: Int,
    onBack: (() -> Unit)?,
    footerEnabled: Boolean,
    footerText: String,
    footerNote: String? = null,
    onNext: () -> Unit,
    content: @Composable () -> Unit,
) {
    Column(Modifier.fillMaxSize().background(Bg)) {
        // header with dots
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (onBack != null) {
                Box(Modifier.size(38.dp).clickable { onBack() }, contentAlignment = Alignment.Center) {
                    VIcon("back", size = 22.dp, color = TextMain)
                }
            } else {
                Spacer(Modifier.width(38.dp))
            }
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                repeat(total) { i ->
                    Box(
                        Modifier
                            .padding(horizontal = 3.dp)
                            .height(6.dp)
                            .width(if (i == step) 18.dp else 6.dp)
                            .clip(RoundedCornerShape(99.dp))
                            .background(if (i == step) Accent else Surface3),
                    )
                }
            }
            Spacer(Modifier.width(38.dp))
        }
        // scrolling content
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(22.dp),
        ) { content() }
        // footer
        Column(
            Modifier.fillMaxWidth().border(1.dp, Line, RoundedCornerShape(0.dp)).padding(22.dp),
        ) {
            PrimaryButton(footerText, enabled = footerEnabled, onClick = onNext)
            if (footerNote != null) {
                Spacer(Modifier.height(10.dp))
                Tiny(footerNote, modifier = Modifier.fillMaxWidth(), align = TextAlign.Center)
            }
        }
    }
}

@Composable
private fun OptionRow(o: Option, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (selected) AccentSoft else Surface1)
            .border(1.dp, if (selected) AccentLine else Line, RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(34.dp).clip(RoundedCornerShape(9.dp)).background(Color(o.color)),
            contentAlignment = Alignment.Center,
        ) {
            Text(o.glyph.ifEmpty { o.name.take(1) }, color = Color.White,
                fontWeight = FontWeight.Bold, fontSize = if (o.glyph.length > 1) 13.sp else 16.sp)
        }
        Spacer(Modifier.width(14.dp))
        Text(o.name, color = TextMain, fontFamily = Sans, fontWeight = FontWeight.Medium, fontSize = 16.sp,
            modifier = Modifier.weight(1f))
        if (selected) VIcon("check", size = 20.dp, color = AccentText, sw = 2.2f)
    }
}

@Composable
private fun ModeCard(selected: Boolean, onClick: () -> Unit, content: @Composable () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(15.dp))
            .background(if (selected) AccentSoft else Surface1)
            .border(1.dp, if (selected) AccentLine else Line, RoundedCornerShape(15.dp))
            .clickable { onClick() }
            .padding(horizontal = 17.dp, vertical = 16.dp),
    ) { content() }
}
