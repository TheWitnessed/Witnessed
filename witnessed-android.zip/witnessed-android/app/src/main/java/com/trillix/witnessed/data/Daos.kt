package com.trillix.witnessed.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface WatchedAppDao {
    @Query("SELECT * FROM watched_app WHERE id = 1 LIMIT 1")
    fun observe(): Flow<WatchedApp?>

    @Query("SELECT * FROM watched_app WHERE id = 1 LIMIT 1")
    suspend fun get(): WatchedApp?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(app: WatchedApp)

    @Query("DELETE FROM watched_app")
    suspend fun clear()
}

@Dao
interface ReceiptDao {
    @Query("SELECT * FROM attempt_receipt ORDER BY timestamp DESC")
    fun observeAll(): Flow<List<AttemptReceipt>>

    @Query("SELECT * FROM attempt_receipt ORDER BY timestamp DESC")
    suspend fun getAll(): List<AttemptReceipt>

    @Insert
    suspend fun insert(receipt: AttemptReceipt)

    @Insert
    suspend fun insertAll(receipts: List<AttemptReceipt>)

    @Query("DELETE FROM attempt_receipt")
    suspend fun clear()
}
