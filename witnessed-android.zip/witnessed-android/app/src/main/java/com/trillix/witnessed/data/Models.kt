package com.trillix.witnessed.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter

enum class Mode { LIGHT, SERIOUS, NOBULL }
enum class Tone { GENTLE, DIRECT, BRUTAL, COACH }
enum class Outcome { BACKED_OUT, CONTINUED, DISMISSED }
enum class DetectionTier { MANUAL, USAGE, ACCESSIBILITY }

@Entity(tableName = "watched_app")
data class WatchedApp(
    @PrimaryKey val id: Long = 1,
    val packageName: String?,        // null for non-app behaviours ("Shopping")
    val appName: String,
    val appColor: Long,              // ARGB packed, for the icon chip
    val appGlyph: String,
    val enabled: Boolean = true,
    val createdAt: Long,
    val mode: Mode,
    val promiseText: String,
    val desiredOutcome: String,      // catalog id, e.g. "time"
    val tone: Tone
)

@Entity(tableName = "attempt_receipt")
data class AttemptReceipt(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val watchedAppId: Long = 1,
    val timestamp: Long,
    val hour: Int,                   // denormalised for fast histograms
    val outcome: Outcome,
    val reasonCategory: String?,     // catalog id
    val reasonText: String?,
    val interventionDurationMs: Long = 0,
    val modeAtTime: Mode,
    val promiseAtTime: String,
    val seeded: Boolean = false
)

/** Enum <-> String converters so Room stores readable values. */
class Converters {
    @TypeConverter fun modeToString(m: Mode): String = m.name
    @TypeConverter fun stringToMode(s: String): Mode = Mode.valueOf(s)

    @TypeConverter fun toneToString(t: Tone): String = t.name
    @TypeConverter fun stringToTone(s: String): Tone = Tone.valueOf(s)

    @TypeConverter fun outcomeToString(o: Outcome): String = o.name
    @TypeConverter fun stringToOutcome(s: String): Outcome = Outcome.valueOf(s)
}
