package com.trillix.witnessed.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.trillix.witnessed.data.INTERVENTION_SUB
import com.trillix.witnessed.data.Mode
import com.trillix.witnessed.data.Outcome
import com.trillix.witnessed.data.REASONS
import com.trillix.witnessed.data.Tone
import com.trillix.witnessed.ui.theme.Accent
import com.trillix.witnessed.ui.theme.AccentLine
import com.trillix.witnessed.ui.theme.AccentSoft
import com.trillix.witnessed.ui.theme.Bg
import com.trillix.witnessed.ui.theme.Dim
import com.trillix.witnessed.ui.theme.Faint
import com.trillix.witnessed.ui.theme.Line
import com.trillix.witnessed.ui.theme.LineStrong
import com.trillix.witnessed.ui.theme.OnAccent
import com.trillix.witnessed.ui.theme.Serif
import com.trillix.witnessed.ui.theme.Surface1
import com.trillix.witnessed.ui.theme.Surface3
import com.trillix.witnessed.ui.theme.TextMain
import kotlinx.coroutines.delay

/**
 * The wall. Complexity scales with mode:
 *  - LIGHT:   promise + Back out / Continue (Continue resolves immediately).
 *  - SERIOUS: Continue -> required reason chip -> Save.
 *  - NOBULL:  5s gate before Continue; then typed reason + explicit confirmation.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun InterventionWall(
    mode: Mode,
    tone: Tone,
    promise: String,
    onResolve: (outcome: Outcome, reasonCategory: String?, reasonText: String?) -> Unit,
) {
    var phase by remember { mutableStateOf("wall") }
    var canContinue by remember { mutableStateOf(mode != Mode.NOBULL) }
    var reason by remember { mutableStateOf<String?>(null) }
    var reasonText by remember { mutableStateOf("") }
    var confirmed by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(Bg)) {
        if (phase == "wall") {
            Column(Modifier.fillMaxSize().padding(horizontal = 28.dp, vertical = 30.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(8.dp).clip(RoundedCornerShape(99.dp)).background(Accent))
                    Spacer(Modifier.width(10.dp))
                    Text("PAUSE · ON THE RECORD", color = Dim, fontFamily = com.trillix.witnessed.ui.theme.Mono,
                        fontSize = 11.sp, letterSpacing = 2.4.sp)
                }

                Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                    Text("YOU SAID —", color = Faint, fontFamily = com.trillix.witnessed.ui.theme.Mono,
                        fontSize = 12.sp, letterSpacing = 1.sp)
                    Spacer(Modifier.height(16.dp))
                    Text("“$promise”", color = TextMain, fontFamily = Serif, fontStyle = FontStyle.Italic,
                        fontSize = 27.sp, lineHeight = 35.sp)
                    Spacer(Modifier.height(20.dp))
                    Text(INTERVENTION_SUB[tone] ?: "", color = Dim, fontSize = 15.sp, lineHeight = 22.sp)
                }

                Column {
                    PrimaryButton("Back out — keep my evening", icon = "back") {
                        onResolve(Outcome.BACKED_OUT, null, null)
                    }
                    Spacer(Modifier.height(11.dp))
                    if (mode == Mode.NOBULL && !canContinue) {
                        DelayGate(seconds = 5) { canContinue = true }
                        Spacer(Modifier.height(11.dp))
                    }
                    GhostButton("Continue anyway", enabled = !(mode == Mode.NOBULL && !canContinue)) {
                        if (mode == Mode.LIGHT) onResolve(Outcome.CONTINUED, null, null) else phase = "reason"
                    }
                    Spacer(Modifier.height(8.dp))
                    Tiny(
                        if (mode == Mode.NOBULL) "No exits hidden. Just a beat to choose consciously."
                        else "No shame. Just a receipt.",
                        modifier = Modifier.fillMaxWidth(), align = TextAlign.Center,
                    )
                }
            }
        } else {
            val isNobull = mode == Mode.NOBULL
            val canSave = if (isNobull) reasonText.trim().length >= 3 && confirmed
            else reason != null && (reason != "other" || reasonText.trim().length >= 2)

            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 26.dp, vertical = 24.dp)) {
                Box(Modifier.size(38.dp).clickable { phase = "wall" }, contentAlignment = Alignment.Center) {
                    VIcon("back", size = 22.dp, color = TextMain)
                }
                Spacer(Modifier.height(8.dp))
                Text(if (isNobull) "Type why you’re choosing this." else "What pulled you in?",
                    color = TextMain, fontFamily = Serif, fontWeight = FontWeight.Medium, fontSize = 27.sp, lineHeight = 32.sp)
                Spacer(Modifier.height(6.dp))
                Lead(if (isNobull) "In your own words. The receipt remembers what you tell it."
                else "One tap. This is the part memory edits out.")
                Spacer(Modifier.height(20.dp))

                if (!isNobull) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(9.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        REASONS.forEach { r ->
                            Chip(r.name, selected = reason == r.id) { reason = r.id }
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                }

                if (isNobull || reason == "other") {
                    LedgerField(
                        reasonText, { reasonText = it },
                        placeholder = if (isNobull) "Right now I’m opening this because…" else "Say more…",
                        minLines = if (isNobull) 4 else 2, fontSize = 16,
                    )
                    Spacer(Modifier.height(16.dp))
                }

                if (isNobull) {
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp))
                            .background(if (confirmed) AccentSoft else Surface1)
                            .border(1.dp, if (confirmed) AccentLine else Line, RoundedCornerShape(13.dp))
                            .clickable { confirmed = !confirmed }.padding(horizontal = 16.dp, vertical = 15.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            Modifier.size(22.dp).clip(RoundedCornerShape(7.dp))
                                .background(if (confirmed) Accent else androidx.compose.ui.graphics.Color.Transparent)
                                .border(1.5.dp, if (confirmed) Accent else LineStrong, RoundedCornerShape(7.dp)),
                            contentAlignment = Alignment.Center,
                        ) { if (confirmed) VIcon("check", size = 15.dp, color = OnAccent, sw = 2.6f) }
                        Spacer(Modifier.width(12.dp))
                        Text("I understand I’m choosing this.", color = TextMain, fontFamily = Serif,
                            fontStyle = FontStyle.Italic, fontSize = 16.sp)
                    }
                    Spacer(Modifier.height(16.dp))
                }

                PrimaryButton(if (isNobull) "Continue anyway" else "Save receipt", enabled = canSave) {
                    val cat = if (isNobull) null else reason?.takeIf { it != "other" }
                    onResolve(Outcome.CONTINUED, cat, reasonText.trim().ifEmpty { null })
                }
                Spacer(Modifier.height(10.dp))
                Tiny("This won’t be used to shame you. It becomes a pattern you can see.",
                    modifier = Modifier.fillMaxWidth(), align = TextAlign.Center)
            }
        }
    }
}

@Composable
private fun DelayGate(seconds: Int, onDone: () -> Unit) {
    var left by remember { mutableIntStateOf(seconds) }
    LaunchedEffect(Unit) {
        while (left > 0) { delay(1000); left -= 1 }
        onDone()
    }
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Sit with it · ${left}s", color = Dim, fontFamily = com.trillix.witnessed.ui.theme.Mono, fontSize = 13.sp)
        Spacer(Modifier.height(8.dp))
        Box(Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(99.dp)).background(Surface3)) {
            Box(Modifier.fillMaxWidth(fraction = (seconds - left).toFloat() / seconds).height(4.dp)
                .clip(RoundedCornerShape(99.dp)).background(Accent))
        }
    }
}
