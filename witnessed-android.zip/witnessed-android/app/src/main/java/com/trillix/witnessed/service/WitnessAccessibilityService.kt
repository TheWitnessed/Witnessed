package com.trillix.witnessed.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import com.trillix.witnessed.Graph
import com.trillix.witnessed.InterventionActivity
import com.trillix.witnessed.data.DetectionTier
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

/**
 * Tier 2 detection. Watches only for the chosen package coming to the
 * foreground (never window content) and launches the wall before the user
 * scrolls. A per-package cooldown prevents the resolve->refocus->retrigger loop.
 */
class WitnessAccessibilityService : AccessibilityService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    @Volatile private var watchedPackage: String? = null
    @Volatile private var enabled = false

    private val cooldownMs = 90_000L
    private val lastTrigger = HashMap<String, Long>()

    override fun onServiceConnected() {
        super.onServiceConnected()
        scope.launch {
            combine(Graph.repository.watchedApp, Graph.repository.userSettings) { app, settings ->
                val pkg = app?.packageName
                val on = settings.detection == DetectionTier.ACCESSIBILITY &&
                    app?.enabled == true && !pkg.isNullOrBlank()
                Pair(pkg, on)
            }.collect { (pkg, on) ->
                watchedPackage = pkg
                enabled = on
            }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (!enabled) return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == applicationContext.packageName) return
        val watched = watchedPackage ?: return

        if (pkg != watched) {
            // A different app reached the foreground — re-arm the wall so the
            // next time the watched app opens it triggers again.
            lastTrigger.remove(watched)
            return
        }

        val now = System.currentTimeMillis()
        if (now - (lastTrigger[watched] ?: 0L) < cooldownMs) return
        lastTrigger[watched] = now

        val intent = Intent(this, InterventionActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            .putExtra(InterventionActivity.EXTRA_FROM_DETECTION, true)
        startActivity(intent)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }
}
