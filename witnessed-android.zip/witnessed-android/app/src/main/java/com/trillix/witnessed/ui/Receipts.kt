package com.trillix.witnessed.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.trillix.witnessed.data.AttemptReceipt
import com.trillix.witnessed.data.MODE_INFO
import com.trillix.witnessed.data.Outcome
import com.trillix.witnessed.data.reasonName
import com.trillix.witnessed.ui.theme.Dim
import com.trillix.witnessed.ui.theme.Faint
import com.trillix.witnessed.ui.theme.Kept
import com.trillix.witnessed.ui.theme.Line
import com.trillix.witnessed.ui.theme.LineDash
import com.trillix.witnessed.ui.theme.Mono
import com.trillix.witnessed.ui.theme.Serif
import com.trillix.witnessed.ui.theme.Surface1
import com.trillix.witnessed.ui.theme.TextMain
import java.util.Calendar

@Composable
fun Receipts(state: UiState) {
    var filter by remember { mutableStateOf("all") }
    val appName = state.app?.appName ?: "App"
    val list = state.receipts.filter {
        when (filter) {
            "back" -> it.outcome == Outcome.BACKED_OUT
            "cont" -> it.outcome == Outcome.CONTINUED
            else -> true
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            listOf("all" to "All", "back" to "Backed out", "cont" to "Continued").forEach { (id, lbl) ->
                Chip(lbl, selected = filter == id) { filter = id }
            }
        }
        Spacer(Modifier.height(18.dp))

        if (list.isEmpty()) {
            Box(Modifier.fillMaxWidth().padding(vertical = 40.dp), contentAlignment = androidx.compose.ui.Alignment.Center) {
                Lead("No receipts here yet.")
            }
            return@Column
        }

        // group by day label, preserving order (receipts already sorted desc)
        val groups = LinkedHashMap<String, MutableList<AttemptReceipt>>()
        list.forEach { r -> groups.getOrPut(dayLabel(r.timestamp)) { mutableListOf() }.add(r) }

        groups.forEach { (label, items) ->
            Kicker("$label · ${items.size}")
            Spacer(Modifier.height(10.dp))
            items.forEach { r ->
                ReceiptCard(r, appName)
                Spacer(Modifier.height(10.dp))
            }
            Spacer(Modifier.height(10.dp))
        }
    }
}

@Composable
private fun ReceiptCard(r: AttemptReceipt, appName: String) {
    val backed = r.outcome == Outcome.BACKED_OUT
    val reasonLabel = when {
        r.reasonCategory != null -> reasonName(r.reasonCategory)
        r.reasonText != null -> "In their words"
        else -> null
    }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Surface1)
            .border(1.dp, Line, RoundedCornerShape(12.dp)),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 15.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text("${appName.uppercase()} · ${fmtTime(r.timestamp)}", color = Dim, fontFamily = Mono,
                fontSize = 11.sp, letterSpacing = 0.6.sp)
            Text(if (backed) "✓ BACKED OUT" else "→ CONTINUED",
                color = if (backed) Kept else com.trillix.witnessed.ui.theme.AccentText,
                fontFamily = Mono, fontSize = 10.5.sp, letterSpacing = 0.8.sp)
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(LineDash))
        Column(Modifier.padding(horizontal = 15.dp, vertical = 13.dp)) {
            Text("“${r.promiseAtTime}”", color = TextMain, fontFamily = Serif, fontStyle = FontStyle.Italic,
                fontSize = 15.5.sp, lineHeight = 21.sp)
            Spacer(Modifier.height(11.dp))
            Row {
                Text("${MODE_INFO[r.modeAtTime]?.name ?: r.modeAtTime.name} mode", color = Faint,
                    fontFamily = Mono, fontSize = 11.5.sp)
                if (reasonLabel != null) {
                    val shown = if (r.reasonText != null) "“${r.reasonText}”" else reasonLabel
                    Text(" · $shown", color = Dim, fontFamily = Mono, fontSize = 11.5.sp)
                }
            }
        }
    }
}

private fun fmtTime(ts: Long): String {
    val c = Calendar.getInstance().apply { timeInMillis = ts }
    val h = c.get(Calendar.HOUR_OF_DAY); val m = c.get(Calendar.MINUTE)
    val ap = if (h < 12) "AM" else "PM"; var hh = h % 12; if (hh == 0) hh = 12
    return String.format("%d:%02d %s", hh, m, ap)
}

private fun dayLabel(ts: Long): String {
    val d = Calendar.getInstance().apply { timeInMillis = ts }
    val now = Calendar.getInstance()
    fun sameDay(a: Calendar, b: Calendar) =
        a.get(Calendar.YEAR) == b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)
    if (sameDay(d, now)) return "Today"
    val y = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
    if (sameDay(d, y)) return "Yesterday"
    val months = listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
    val days = listOf("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
    val dow = days[d.get(Calendar.DAY_OF_WEEK) - 1]
    return "$dow, ${months[d.get(Calendar.MONTH)]} ${d.get(Calendar.DAY_OF_MONTH)}"
}
