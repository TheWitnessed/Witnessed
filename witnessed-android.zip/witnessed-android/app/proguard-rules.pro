# Keep Room entities/daos (annotation processing already generates impls).
-keep class com.trillix.witnessed.data.** { *; }
